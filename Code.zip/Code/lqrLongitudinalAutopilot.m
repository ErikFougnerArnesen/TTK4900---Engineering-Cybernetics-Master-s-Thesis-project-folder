function [de, debug, state] = lqrLongitudinalAutopilot(...
    h_cmd, h, u_b, w_b, q, theta, phi, wind_b, K_lon, p, alpha_t, de_trim, dt, state)
% LQRLONGITUDINALAUTOPILOT  LQR longitudinal autopilot for altitude hold.
%
%   [de, debug, state] = lqrLongitudinalAutopilot(h_cmd, h, u_b, w_b, ...
%       q, theta, phi, wind_b, K_lon, p, alpha_t, de_trim, dt, state)
%
%   Applies the precomputed LQR gain matrix K_lon to the augmented
%   longitudinal state vector to produce an elevator command. The
%   control law tracks altitude via full-state feedback including
%   airspeed perturbation (du), vertical velocity perturbation (dw),
%   pitch rate (q), pitch angle perturbation (dtheta), altitude error
%   (dh), and altitude error integral.
%
%   Augmented state:  xi = [du, dw, dq, dtheta, dh, x_I]'
%     du     : u_air - u_trim [m/s]
%     dw     : w_air - w_trim [m/s]
%     dq     : pitch rate (q - 0) [rad/s]
%     dtheta : theta - theta_trim [rad]
%     dh     : h - h_cmd [m]  (altitude error)
%     x_I    : integral of altitude error [m*s]
%
%   Control law:  dde = -K_lon * xi
%                 de  = de_trim + dde
%
%   Inputs:
%     h_cmd   : commanded altitude [m] (positive up)
%     h       : current altitude [m] (positive up, h = -pd)
%     u_b     : body-frame x-velocity [m/s]
%     w_b     : body-frame z-velocity [m/s]
%     q       : pitch rate [rad/s]
%     theta   : pitch angle [rad]
%     wind_b  : wind in body frame [uw; vw; ww] [m/s]
%     K_lon   : LQR gain matrix (1x6) from lqrLongitudinalDesign()
%     p       : parameter struct from tomahawk_params()
%     alpha_t : trim angle of attack [rad]
%     de_trim : trim elevator deflection [rad]
%     dt      : sampling time [s]
%     state   : struct with persistent states:
%                 state.h_int : altitude error integral [m*s]
%
%   Outputs:
%     de    : total elevator command [rad] (trim + perturbation)
%     debug : struct with internal signals
%     state : updated state struct

% =========================================================================
% Trim values
% =========================================================================
Va_trim = p.Va_trim;
u_trim  = Va_trim * cos(alpha_t);
w_trim  = Va_trim * sin(alpha_t);
th_trim = alpha_t;   % theta_trim = alpha_trim for level flight

% =========================================================================
% Air-relative velocities (perturbations from trim)
% =========================================================================
u_air = u_b - wind_b(1);
w_air = w_b - wind_b(3);

du     = u_air - u_trim;
dw     = w_air - w_trim;
dq     = q;                     % q_trim = 0
dtheta = theta - th_trim;
dh     = h - h_cmd;

% =========================================================================
% Assemble augmented state vector
% =========================================================================
xi = [du; dw; dq; dtheta; dh; state.h_int];

% =========================================================================
% LQR control law: dde = -K * xi
% =========================================================================
dde_fb = -K_lon * xi;

% =========================================================================
% Turn-compensation feedforward
% =========================================================================
%   In a banked turn, vertical lift = L*cos(phi). To maintain altitude,
%   the required load factor is n = 1/cos(phi), demanding extra AoA:
%       delta_alpha = (CL_trim / CL_alpha) * (n - 1)
%
%   The elevator deflection to produce this extra AoA follows from the
%   pitching moment equilibrium (Cm = 0 in steady state):
%       Cm_alpha * delta_alpha + Cm_de * dde_ff = 0
%       dde_ff = -(Cm_alpha / Cm_de) * delta_alpha
%
%   This acts immediately when banking begins, preventing the altitude
%   sag that would otherwise occur while the LQR feedback catches up.
%
%   Note: CL_trim/CL_alpha != alpha_trim because CL has a non-zero
%   intercept CL0. Using alpha_trim alone undercompensates by ~50%.

CL_trim  = polyval(p.CL_poly, alpha_t);
CL_alpha = polyval(polyder(p.CL_poly), alpha_t);
Cm_alpha = polyval(polyder(p.Cm_poly), alpha_t);
Cm_de    = p.Cm_de;

n_load      = 1 / max(cos(phi), 0.5);      % load factor, limited to n <= 2
delta_alpha = (CL_trim / CL_alpha) * (n_load - 1);
dde_ff      = -(Cm_alpha / Cm_de) * delta_alpha;

% Total elevator = trim + LQR feedback + feedforward
dde    = dde_fb + dde_ff;
de_raw = de_trim + dde;

% Saturate at physical limits
de = max(-p.elevon_max, min(p.elevon_max, de_raw));

% =========================================================================
% Propagate integral state with anti-windup
% =========================================================================
de_sat = (abs(de_raw) > p.elevon_max);

if ~de_sat || (dh * state.h_int < 0)
    state.h_int = state.h_int + dt * dh;
end

% Hard clamp
h_int_max = 5 * 30;   % 150 m*s
state.h_int = max(-h_int_max, min(h_int_max, state.h_int));

% =========================================================================
% Debug output
% =========================================================================
debug.xi      = xi;
debug.dde_fb  = dde_fb;
debug.dde_ff  = dde_ff;
debug.dde     = dde;
debug.de_raw  = de_raw;
debug.de      = de;
debug.du      = du;
debug.dw      = dw;
debug.dh      = dh;
debug.n_load  = n_load;

end
