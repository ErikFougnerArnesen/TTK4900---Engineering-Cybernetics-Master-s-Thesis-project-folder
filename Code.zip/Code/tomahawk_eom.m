function dx = tomahawk_eom(t, x, p, ctrl_fun, wind_b)
% TOMAHAWK_EOM  Twelve-state equations of motion for a rigid-body missile.
%
%   dx = tomahawk_eom(t, x, p, ctrl_fun)
%   dx = tomahawk_eom(t, x, p, ctrl_fun, wind_b)
%
%   Implements the 6-DOF EoM from Beard & McLain Ch. 2-4
%   (TTK 4190 lecture slide 52), with aerodynamic forces/moments computed
%   from the OpenVSP coefficient set stored in the parameter struct p.
%
%   Wind enters through the relative velocity (Beard Ch. 4.4, p.61-64):
%     V_a = V_g - V_w
%   The aerodynamic forces depend on the airspeed vector (u_r, v_r, w_r),
%   while the kinematic equations use the ground speed (u, v, w).
%
%   State vector  x = [pn pe pd  u v w  phi theta psi  p q r]'
%     pn, pe, pd   : NED position                     [m]
%     u, v, w      : body-frame GROUND velocity        [m/s]
%     phi,theta,psi: Euler angles (roll, pitch, yaw)   [rad]
%     p, q, r      : body angular rates                [rad/s]
%
%   Inputs
%     t        : time  [s]
%     x        : state vector (12x1)
%     p        : parameter struct from tomahawk_params()
%     ctrl_fun : function handle  [de, da, dr] = ctrl_fun(t, x)
%                returning elevator, aileron, and rudder commands [rad]
%     wind_b   : (optional) wind velocity in body frame [uw; vw; ww] [m/s]
%                If omitted, no-wind conditions are assumed.

%% ---- Unpack state ------------------------------------------------------
u   = x(4);   v  = x(5);  w  = x(6);       % body velocity (ground)
phi = x(7);   th = x(8);  psi = x(9);      % Euler angles
pp  = x(10);  q  = x(11); r  = x(12);      % angular rates

%% ---- Control inputs ----------------------------------------------------
[de, da, dr] = ctrl_fun(t, x);

% Apply actuator limits (independent surfaces: elevator, aileron, rudder)
de = max(-p.elevon_max, min(p.elevon_max, de));
da = max(-p.aileron_max, min(p.aileron_max, da));
dr = max(-p.rudder_max, min(p.rudder_max, dr));

%% ---- Wind and relative velocity (Beard Ch. 4.4) -----------------------
if nargin < 5 || isempty(wind_b)
    uw = 0;  vw = 0;  ww = 0;
else
    uw = wind_b(1);
    vw = wind_b(2);
    ww = wind_b(3);
end

% Relative (air-mass) velocity in body frame
ur = u - uw;
vr = v - vw;
wr = w - ww;

%% ---- Airspeed, angle of attack, sideslip (from relative velocity) -----
Va    = sqrt(ur^2 + vr^2 + wr^2);
Va    = max(Va, 1);                       % protect against zero airspeed
alpha = atan2(wr, ur);
beta  = asin(max(-1, min(1, vr / Va)));

%% ---- Dynamic pressure and non-dimensional rates -----------------------
qbar  = 0.5 * p.rho0 * Va^2;
chat  = p.c / (2 * Va);                   % c / (2*Va)  for pitch rate
bhat  = p.b / (2 * Va);                   % b / (2*Va)  for roll/yaw rates

%% ---- Longitudinal coefficients ----------------------------------------
CL = polyval(p.CL_poly, alpha);
CD = polyval(p.CD_poly, alpha);
Cm = polyval(p.Cm_poly, alpha);

CL = CL + p.CL_q * chat * q + p.CL_de * de;
CD = CD + p.CD_q * chat * q + p.CD_de * de;
Cm = Cm + p.Cm_q * chat * q + p.Cm_de * de;

%% ---- Stability-to-body axis rotation (slide 23) -----------------------
ca = cos(alpha);  sa = sin(alpha);
CX = -CD * ca + CL * sa;
CZ = -CD * sa - CL * ca;

%% ---- Lateral-directional coefficients (slide 38) ----------------------
CY = p.CY0 + p.CY_beta * beta ...
   + p.CY_p * bhat * pp + p.CY_r * bhat * r ...
   + p.CY_da * da       + p.CY_dr * dr;

Cl = p.Cl0 + p.Cl_beta * beta ...
   + p.Cl_p * bhat * pp + p.Cl_r * bhat * r ...
   + p.Cl_da * da       + p.Cl_dr * dr;

Cn = p.Cn0 + p.Cn_beta * beta ...
   + p.Cn_p * bhat * pp + p.Cn_r * bhat * r ...
   + p.Cn_da * da       + p.Cn_dr * dr;

%% ---- Aerodynamic forces and moments in the body frame ------------------
fx_aero = qbar * p.S * CX;
fy_aero = qbar * p.S * CY;
fz_aero = qbar * p.S * CZ;

l_aero  = qbar * p.S * p.b * Cl;
m_aero  = qbar * p.S * p.c * Cm;
n_aero  = qbar * p.S * p.b * Cn;

%% ---- Gravity force in body frame (slide 21) ---------------------------
cphi = cos(phi);  sphi = sin(phi);
cth  = cos(th);   sth  = sin(th);

fx_grav = -p.mass * p.g * sth;
fy_grav =  p.mass * p.g * cth * sphi;
fz_grav =  p.mass * p.g * cth * cphi;

%% ---- Thrust (constant, along body x-axis) -----------------------------
fx_thrust = p.T_trim;

%% ---- Total forces and moments ------------------------------------------
fx = fx_aero + fx_grav + fx_thrust;
fy = fy_aero + fy_grav;
fz = fz_aero + fz_grav;

ll = l_aero;
mm = m_aero;
nn = n_aero;

%% ---- Equations of motion (slides 18 and 52) ----------------------------
dx = zeros(12, 1);

% Kinematic equations  -  NED position  (uses GROUND velocity, not airspeed)
cpsi = cos(psi);  spsi = sin(psi);

dx(1) = cth*cpsi * u  + (sphi*sth*cpsi - cphi*spsi) * v ...
      + (cphi*sth*cpsi + sphi*spsi) * w;
dx(2) = cth*spsi * u  + (sphi*sth*spsi + cphi*cpsi) * v ...
      + (cphi*sth*spsi - sphi*cpsi) * w;
dx(3) = -sth * u  + sphi*cth * v  + cphi*cth * w;

% Translational dynamics
dx(4) = r*v - q*w + fx / p.mass;
dx(5) = pp*w - r*u + fy / p.mass;
dx(6) = q*u - pp*v + fz / p.mass;

% Euler angle kinematics
tth = tan(th);
dx(7)  = pp + sphi * tth * q + cphi * tth * r;
dx(8)  =      cphi * q       - sphi * r;
dx(9)  =      sphi / cth * q + cphi / cth * r;

% Rotational dynamics  (Gamma formulation, slide 18)
dx(10) = p.Gam1 * pp * q - p.Gam2 * q * r ...
       + p.Gam3 * ll     + p.Gam4 * nn;
dx(11) = p.Gam5 * pp * r - p.Gam6 * (pp^2 - r^2) ...
       + mm / p.Jy;
dx(12) = p.Gam7 * pp * q - p.Gam1 * q * r ...
       + p.Gam4 * ll     + p.Gam8 * nn;

end
