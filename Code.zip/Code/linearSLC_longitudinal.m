function [de, theta_c_out, debug, state] = linearSLC_longitudinal(...
    h_cmd, h, theta, q, params, gains, dt, state, theta_trim, phi)
% LINEARSLC_LONGITUDINAL  Longitudinal SLC autopilot with gains from linearization.
%
%   Implements Beard & McLain Ch. 6.2 successive loop closure:
%     Inner  : pitch attitude hold   theta_c -> de  (PD with q damping)
%     Outer  : altitude hold         h_c -> theta_c (PI)
%
%   Additional features from altitudePitchAutopilot.m: 
%     - Turn-compensation feedforward for banked flight
%     - Reference model for altitude command smoothing
%
%   Gains are pre-computed from the linearized state-space model.
%
%   Inputs:
%     h_cmd      : commanded altitude [m] (positive up)
%     h          : current altitude [m]
%     theta      : pitch angle [rad]
%     q          : pitch rate [rad/s]
%     Va         : airspeed [m/s]
%     params     : parameter struct from tomahawk_params()
%     gains      : struct from tomahawk_slc_gains() with fields:
%                  kp_theta, kd_theta, kp_h, ki_h
%     dt         : sampling time [s]
%     state      : persistent state struct (see initialization below)
%     theta_trim : trim pitch angle [rad]
%     phi        : roll angle [rad] for turn compensation
%
%   Outputs:
%     de          : elevator command [rad]
%     theta_c_out : commanded pitch angle [rad] (for logging)
%     debug       : struct with internal signals
%     state       : updated state struct
%
%   State initialization (call before first use):
%     state.h_ref    = initial_h;
%     state.hdot_ref = 0;
%     state.h_int    = 0;

if nargin < 10 || isempty(phi)
    phi = 0;
end

% =========================================================================
% Limits
% =========================================================================
theta_max = deg2rad(20);
de_max    = params.elevon_max;

% =========================================================================
% Reference model for altitude command (2nd order, critically damped)
% =========================================================================
wn_ref   = 0.8;    % bandwith frequency 0.8     
zeta_ref = 1.0;    % critcally damped
hdot_max = 20;       % max climb/dive rate [m/s]

h_ref_ddot = -2*zeta_ref*wn_ref*state.hdot_ref ...
             - wn_ref^2*(state.h_ref - h_cmd);
state.hdot_ref = state.hdot_ref + dt * h_ref_ddot;
state.hdot_ref = max(-hdot_max, min(hdot_max, state.hdot_ref));
state.h_ref = state.h_ref + dt * state.hdot_ref;


% =========================================================================
% Turn-compensation feedforward
%   In a banked turn, vertical lift = L*cos(phi).  To maintain altitude,
%   extra AoA is needed: delta_alpha = (CL_trim/CL_alpha) * (1/cos(phi) - 1)
% =========================================================================
alpha_trim = theta_trim;   % for gamma = 0
CL_trim  = polyval(params.CL_poly, alpha_trim);
CL_alpha = polyval(polyder(params.CL_poly), alpha_trim);

n_load   = 1 / max(cos(phi), 0.5);
theta_ff = (CL_trim / CL_alpha) * (n_load - 1);

% =========================================================================
% Outer loop: altitude hold (PI)
% =========================================================================
h_err = state.h_ref - h;

theta_c_unsat = theta_trim + gains.kp_h * h_err + gains.ki_h * state.h_int ...
              + theta_ff;

% Saturate pitch command
theta_c = max(-theta_max, min(theta_max, theta_c_unsat));

% Anti-windup
if abs(theta_c_unsat - theta_c) < 1e-6 || (h_err * state.h_int < 0)
    state.h_int = state.h_int + dt * h_err;
end

% =========================================================================
% Inner loop: pitch attitude hold (PD with q damping)
% =========================================================================
e_theta = ssa(theta_c - theta);
de = gains.kp_theta * e_theta - gains.kd_theta * q;

de = max(-de_max, min(de_max, de));

% =========================================================================
% Outputs
% =========================================================================
theta_c_out = theta_c;

debug.e_h       = h_err;
debug.e_theta   = e_theta;
debug.h_ref     = state.h_ref;
debug.theta_ff  = theta_ff;
debug.theta_c   = theta_c;

end