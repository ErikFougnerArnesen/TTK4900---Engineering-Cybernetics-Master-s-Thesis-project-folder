function [K, design] = lqrLateralDesign(lin)
% LQRLATERALDESIGN  LQR gain design for the lateral autopilot.
%
%   [K, design] = lqrLateralDesign(lin)
%
%   Takes the linearized state-space model from tomahawk_linearize() and
%   augments the lateral state with a heading integral for zero steady-state
%   tracking error, then solves the LQR problem using Bryson's rule for
%   initial Q/R weights.
%
%   Unlike the Beard textbook approach (single-input da + yaw damper),
%   this design uses BOTH da and dr as simultaneous LQR inputs, so the
%   Riccati equation accounts for all roll-yaw coupling terms (Cn_da,
%   Cl_dr, etc.) and distributes control effort optimally.
%
%   Lateral state:  x_lat = [v, p, r, phi, psi]'   (from lin.A_lat)
%   Inputs:         u_lat = [da, dr]'               (from lin.B_lat)
%   Augmented:      xi    = [v, p, r, phi, psi_error, integral(psi_error)]'
%
%   Inputs:
%     lin  : linearization struct from tomahawk_linearize(), containing:
%              .A_lat    : 5x5 lateral state matrix
%              .B_lat    : 5x2 lateral input matrix [da, dr]
%              .Va_trim  : trim airspeed [m/s]
%              (eigenvalue fields are used for diagnostics)
%
%   Outputs:
%     K      : LQR gain matrix (2x6), u = -K * xi
%     design : struct with A_lat, B_lat, eigenvalues, Q, R, etc.
%
%   References:
%     Beard & McLain, Ch. 5.5.2 (Eq. 5.42, Table 5.1)
%     Beard & McLain, Ch. 6.3.1 (LQR with integral augmentation)

%% ---- Pull lateral sub-model from linearization struct ------------------
A_lat = lin.A_lat;
B_lat = lin.B_lat;
Va    = lin.Va_trim;

%% ---- Integral augmentation (Beard Sec. 6.3.1) -------------------------
%   Augment state with heading error integral:
%     x_I = integral( psi - psi_cmd ) dt
%   Using H_lat = [0, 0, 0, 0, 1] to extract psi.
%
%   Augmented system:
%     xi = [v, p, r, phi, psi_error, x_I]'
%     xi_dot = A_bar * xi + B_bar * u

H_lat = [0, 0, 0, 0, 1];

A_bar = [A_lat,       zeros(5,1);
         H_lat,       0         ];

B_bar = [B_lat;
         0, 0 ];

%% ---- LQR weight matrices (Bryson's rule starting point) ---------------
%   q_i = 1 / (maximum acceptable value of state i)^2
%   r_j = 1 / (maximum acceptable value of input j)^2

% Sideslip velocity: 1 deg beta at Va -> v_max = Va * sin(1 deg)
v_max   = Va * sind(1);
q_v     = 1 / v_max^2;

q_p     = 1 / deg2rad(60)^2;      % roll rate: 60 deg/s
q_r     = 1 / deg2rad(20)^2;      % yaw rate: 20 deg/s
q_phi   = 1 / deg2rad(40)^2;      % bank angle: 40 deg
q_psi   = 1 / deg2rad(3)^2;      % heading error: 3 deg
q_I     = 1 / (5)^2;             % integral: 5 rad/s

r_da    = 1 / deg2rad(15)^2;      % aileron: 15 deg
r_dr    = 1 / deg2rad(15)^2;      % rudder: 15 deg

Q = diag([q_v, q_p, q_r, q_phi, q_psi, q_I]);
R = diag([r_da, r_dr]);

%% ---- Verify controllability --------------------------------------------
C_mat = ctrb(A_bar, B_bar);
rank_C = rank(C_mat);
n_aug  = size(A_bar, 1);

if rank_C < n_aug
    warning('Augmented system is NOT fully controllable (rank %d / %d)', ...
        rank_C, n_aug);
end

%% ---- Solve LQR ---------------------------------------------------------
[K, S, eig_cl] = lqr(A_bar, B_bar, Q, R);

%% ---- Open-loop analysis ------------------------------------------------
eig_ol = eig(A_lat);

fprintf('\n--- LQR Lateral Autopilot Design ---\n');
fprintf('  (A_lat, B_lat from tomahawk_linearize)\n\n');

fprintf('  A_lat (5x5):\n');
lat_labels = {'v','p','r','phi','psi'};
fprintf('         ');
for j = 1:5, fprintf('%10s', lat_labels{j}); end
fprintf('\n');
for i = 1:5
    fprintf('  %5s: ', lat_labels{i});
    for j = 1:5
        fprintf('%10.4f', A_lat(i,j));
    end
    fprintf('\n');
end

fprintf('\n  B_lat (5x2):\n');
fprintf('         %10s%10s\n', 'da', 'dr');
for i = 1:5
    fprintf('  %5s: %10.4f%10.4f\n', lat_labels{i}, B_lat(i,1), B_lat(i,2));
end

fprintf('\n  Open-loop lateral eigenvalues:\n');
for i = 1:length(eig_ol)
    if imag(eig_ol(i)) == 0
        fprintf('    lambda_%d = %8.4f          (real)\n', i, real(eig_ol(i)));
    elseif imag(eig_ol(i)) > 0
        wn = abs(eig_ol(i));
        zeta = -real(eig_ol(i)) / wn;
        fprintf('    lambda_%d = %8.4f + %8.4fi  (wn=%.2f, zeta=%.3f)\n', ...
            i, real(eig_ol(i)), imag(eig_ol(i)), wn, zeta);
    end
end

fprintf('\n  Closed-loop eigenvalues (augmented):\n');
for i = 1:length(eig_cl)
    if imag(eig_cl(i)) == 0
        fprintf('    lambda_%d = %8.4f          (real)\n', i, real(eig_cl(i)));
    elseif imag(eig_cl(i)) > 0
        wn = abs(eig_cl(i));
        zeta = -real(eig_cl(i)) / wn;
        fprintf('    lambda_%d = %8.4f + %8.4fi  (wn=%.2f, zeta=%.3f)\n', ...
            i, real(eig_cl(i)), imag(eig_cl(i)), wn, zeta);
    end
end

fprintf('\n  Controllability rank: %d / %d\n', rank_C, n_aug);

fprintf('\n  K matrix (2x6):\n');
fprintf('    da gains: [%9.4f %9.4f %9.4f %9.4f %9.4f %9.4f]\n', K(1,:));
fprintf('    dr gains: [%9.4f %9.4f %9.4f %9.4f %9.4f %9.4f]\n', K(2,:));
fprintf('              [ v        p        r        phi      psi_e    x_I  ]\n\n');

%% ---- Pack output struct ------------------------------------------------
design.A_lat  = A_lat;
design.B_lat  = B_lat;
design.A_bar  = A_bar;
design.B_bar  = B_bar;
design.H_lat  = H_lat;
design.Q      = Q;
design.R      = R;
design.K      = K;
design.S_ric  = S;
design.eig_ol = eig_ol;
design.eig_cl = eig_cl;
design.rank_C = rank_C;

end
