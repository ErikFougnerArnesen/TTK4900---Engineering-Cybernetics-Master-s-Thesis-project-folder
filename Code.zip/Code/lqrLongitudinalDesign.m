function [K, design] = lqrLongitudinalDesign(lin)
% LQRLONGITUDINALDESIGN  LQR gain design for the longitudinal autopilot.
%
%   [K, design] = lqrLongitudinalDesign(lin)
%
%   Takes the linearized longitudinal state-space model from
%   tomahawk_linearize() and augments the state with an altitude integral
%   for zero steady-state tracking error, then solves the LQR problem.
%
%   Longitudinal state:  x_lon = [u, w, q, theta, h]'  (from lin.A_lon)
%   Input:               u_lon = [de]                   (from lin.B_lon)
%   Augmented:           xi    = [du, dw, dq, dtheta, dh, integral(h_err)]'
%
%   Inputs:
%     lin  : linearization struct from tomahawk_linearize(), containing:
%              .A_lon    : 5x5 longitudinal state matrix
%              .B_lon    : 5x1 longitudinal input vector (elevator)
%              .Va_trim  : trim airspeed [m/s]
%              .g        : gravitational acceleration [m/s^2]
%
%   Outputs:
%     K      : LQR gain matrix (1x6), dde = -K * xi
%     design : struct with A_lon, B_lon, eigenvalues, Q, R, etc.
%
%   References:
%     Beard & McLain, Ch. 5.5.3 (Eq. 5.49), Appendix F
%     Beard & McLain, Ch. 6.3.1 (LQR with integral augmentation)

%% ---- Pull longitudinal sub-model from linearization struct -------------
A_lon = lin.A_lon;
B_lon = lin.B_lon;
Va    = lin.Va_trim;
n_lon = size(A_lon, 1);   % should be 5

%% ---- Print A and B for inspection -------------------------------------
fprintf('\n--- LQR Longitudinal Autopilot Design ---\n');
fprintf('  (A_lon, B_lon from tomahawk_linearize)\n\n');

state_labels = {'du', 'dw', 'dq', 'dtheta', 'dh'};
fprintf('  A_lon (5x5):\n');
fprintf('         ');
for j = 1:n_lon, fprintf('%10s', state_labels{j}); end
fprintf('\n');
for i = 1:n_lon
    fprintf('  %6s: ', state_labels{i});
    for j = 1:n_lon
        fprintf('%10.4f', A_lon(i,j));
    end
    fprintf('\n');
end

fprintf('\n  B_lon (5x1):\n');
for i = 1:n_lon
    fprintf('  %6s: %10.4f\n', state_labels{i}, B_lon(i));
end

%% ---- Open-loop eigenvalues --------------------------------------------
eig_ol = eig(A_lon);

fprintf('\n  Open-loop longitudinal eigenvalues:\n');
for i = 1:length(eig_ol)
    if imag(eig_ol(i)) == 0
        fprintf('    lambda_%d = %8.4f          (real)\n', i, real(eig_ol(i)));
    elseif imag(eig_ol(i)) > 0
        wn = abs(eig_ol(i));
        zeta = -real(eig_ol(i)) / wn;
        fprintf('    lambda_%d = %8.4f + %8.4fi  (wn=%.3f, zeta=%.4f)\n', ...
            i, real(eig_ol(i)), imag(eig_ol(i)), wn, zeta);
    end
end

%% ---- Integral augmentation (altitude tracking) -------------------------
%   Augment with altitude error integral:
%     x_I = integral(h - h_cmd) dt
%   H_lon = [0, 0, 0, 0, 1] extracts h.

H_lon = [0, 0, 0, 0, 1];

A_bar = [A_lon,       zeros(n_lon,1);
         H_lon,       0             ];

B_bar = [B_lon;
         0   ];

%% ---- LQR weight matrices (Bryson's rule) -------------------------------
%   Augmented state: [du, dw, dq, dtheta, dh, x_I]'
w_long = 1;

q_u     = w_long / 5^2;                % airspeed perturbation: 5 m/s
q_w     = w_long / 18^2;                % vertical velocity: ~2 deg AoA
q_q     = w_long / deg2rad(10)^2;      % pitch rate: 10 deg/s
q_theta = w_long / deg2rad(30)^2;      % pitch angle: 10 deg
q_h     = w_long / 1.5^2;              % altitude error: 1.5 m
q_I     = w_long / 15^2;               % altitude integral: 15 m*s

r_de    = 1 / deg2rad(15)^2;      % elevator perturbation: 15 deg

Q = diag([q_u, q_w, q_q, q_theta, q_h, q_I]);
R = r_de;

%% ---- Controllability check ---------------------------------------------
C_mat = ctrb(A_bar, B_bar);
rank_C = rank(C_mat);
n_aug  = size(A_bar, 1);

if rank_C < n_aug
    warning('Augmented system is NOT fully controllable (rank %d / %d)', ...
        rank_C, n_aug);
end

fprintf('\n  Controllability rank: %d / %d\n', rank_C, n_aug);

%% ---- Solve LQR ---------------------------------------------------------
[K, S, eig_cl] = lqr(A_bar, B_bar, Q, R);

fprintf('\n  Closed-loop eigenvalues (augmented):\n');
for i = 1:length(eig_cl)
    if imag(eig_cl(i)) == 0
        fprintf('    lambda_%d = %8.4f          (real)\n', i, real(eig_cl(i)));
    elseif imag(eig_cl(i)) > 0
        wn = abs(eig_cl(i));
        zeta = -real(eig_cl(i)) / wn;
        fprintf('    lambda_%d = %8.4f + %8.4fi  (wn=%.3f, zeta=%.4f)\n', ...
            i, real(eig_cl(i)), imag(eig_cl(i)), wn, zeta);
    end
end

fprintf('\n  K matrix (1x6):\n');
fprintf('    de gains: [%9.4f %9.4f %9.4f %9.4f %9.4f %9.4f]\n', K);
fprintf('              [ du       dw       dq       dtheta   dh       x_I  ]\n\n');

%% ---- Pack output struct ------------------------------------------------
design.A_lon  = A_lon;
design.B_lon  = B_lon;
design.A_bar  = A_bar;
design.B_bar  = B_bar;
design.H_lon  = H_lon;
design.Q      = Q;
design.R      = R;
design.K      = K;
design.S_ric  = S;
design.eig_ol = eig_ol;
design.eig_cl = eig_cl;
design.rank_C = rank_C;

end
