function gains = tomahawk_slc_gains(lin, design)
% TOMAHAWK_SLC_GAINS  Compute SLC autopilot gains from the linearized model.
%
%   gains = tomahawk_slc_gains(lin, design)
%
%   Follows Beard & McLain Ch. 6 successive loop closure methodology.
%   All gains are computed analytically from the transfer function
%   coefficients extracted by tomahawk_linearize().
%
%   Inputs
%     lin    : struct from tomahawk_linearize()
%     design : struct with design parameters (all optional, defaults used)
%       .zeta_phi    - roll damping ratio          (default 0.9)
%       .wn_phi      - roll natural frequency      (default from max da)
%       .zeta_chi    - course damping ratio         (default 1.5)
%       .W_chi       - course/roll bandwidth sep.   (default 10)
%       .zeta_theta  - pitch damping ratio          (default 0.9)
%       .wn_theta    - pitch natural frequency      (default from max de)
%       .zeta_h      - altitude damping ratio       (default 1.5)
%       .W_h         - altitude/pitch bandwidth sep.(default 15)
%       .k_r         - yaw damper gain             (default computed)
%       .p_wo        - washout filter pole          (default 5 rad/s)
%
%   Output
%     gains : struct with all autopilot gains

if nargin < 2, design = struct(); end

%% ---- Default design parameters ----------------------------------------
def = @(s, val) set_default(design, s, val);
zeta_phi   = def('zeta_phi',   0.9);
zeta_chi   = def('zeta_chi',   1.5);
W_chi      = def('W_chi',      10);
zeta_theta = def('zeta_theta', 0.9);
W_h        = def('W_h',        8);
p_wo       = def('p_wo',       5.0);

% Max control deflections (for natural frequency limits)
da_max = deg2rad(15);
de_max = deg2rad(15);
phi_max = deg2rad(45);    % max bank angle for roll/course

Va = lin.Va_trim;
g  = lin.g;

%% ---- Roll attitude hold (inner lateral loop) ---------------------------
% TF: phi(s)/da(s) = a_phi2 / (s^2 + a_phi1*s)
%
% Closed loop with PD: da = kp_phi*(phi_c - phi) - kd_phi*p
%   phi(s)/phi_c(s) = kp_phi*a_phi2 / (s^2 + (a_phi1+kd_phi*a_phi2)*s + kp_phi*a_phi2)
%
% Desired: s^2 + 2*zeta*wn*s + wn^2
%   wn_phi^2 = kp_phi * a_phi2
%   2*zeta_phi*wn_phi = a_phi1 + kd_phi*a_phi2

% Choose wn_phi: from max da for max phi error
if isfield(design, 'wn_phi')
    wn_phi = design.wn_phi;
else
    % Beard's formula: wn_phi = sqrt(a_phi2 * da_max / phi_max)
    wn_phi = sqrt(abs(lin.a_phi2) * da_max / phi_max);
end

kp_phi = wn_phi^2 / lin.a_phi2;
kd_phi = (2 * zeta_phi * wn_phi - lin.a_phi1) / lin.a_phi2;

gains.kp_phi = kp_phi;
gains.kd_phi = kd_phi;
gains.wn_phi = wn_phi;
gains.zeta_phi = zeta_phi;

% DC gain of roll loop
K_phi_DC = kp_phi * lin.a_phi2 / wn_phi^2;
gains.K_phi_DC = K_phi_DC;

fprintf('\n--- Roll Attitude Hold ---\n');
fprintf('  wn_phi  = %.3f rad/s\n', wn_phi);
fprintf('  kp_phi  = %.6f\n', kp_phi);
fprintf('  kd_phi  = %.6f\n', kd_phi);
fprintf('  K_DC    = %.4f\n', K_phi_DC);

%% ---- Course hold (outer lateral loop) ----------------------------------
% TF: chi(s)/phi(s) = g/(Vg*s)  (assuming phi loop is fast enough)
%
% PI controller: phi_c = kp_chi*(chi_c - chi) + ki_chi*int(chi_c - chi)
%   chi(s)/chi_c(s) = (kp_chi*g/Vg*s + ki_chi*g/Vg) / (s^2 + kp_chi*g/Vg*s + ki_chi*g/Vg)
%
% Desired: wn_chi and zeta_chi
% With bandwidth separation: wn_chi = wn_phi / W_chi

wn_chi = wn_phi / W_chi;

% Use Vg ~ Va for zero-wind
Vg = Va;

kp_chi = 2 * zeta_chi * wn_chi * Vg / g;
ki_chi = wn_chi^2 * Vg / g;

gains.kp_chi = kp_chi;
gains.ki_chi = ki_chi;
gains.wn_chi = wn_chi;
gains.zeta_chi = zeta_chi;

fprintf('\n--- Course Hold ---\n');
fprintf('  wn_chi  = %.4f rad/s\n', wn_chi);
fprintf('  kp_chi  = %.4f\n', kp_chi);
fprintf('  ki_chi  = %.6f\n', ki_chi);

%% ---- Yaw damper --------------------------------------------------------
% Washout filter on yaw rate r driving rudder dr.
% dr = kr * (s / (s + p_wo)) * r
% Gain kr chosen to place dutch-roll damping at desired level.

if isfield(design, 'k_r')
    kr = design.k_r;
else
    % Design heuristic: choose kr to approximately double dutch-roll damping
    % From the lateral model, the dutch-roll mode is influenced by:
    %   N_r and N_dr (yaw damping and rudder effectiveness)
    N_r  = lin.A_lat(3, 3);   % dr_dot / dr  (yaw damping)
    N_dr = lin.B_lat(3, 2);   % dr_dot / d(dr) (rudder effectiveness)
    
    % Desired additional damping: add delta_zeta to dutch roll
    if isfield(lin, 'dutch_roll')
        zeta_dr_current = lin.dutch_roll.zeta;
        wn_dr = lin.dutch_roll.wn;
        % Target zeta ~ 0.5
        delta_zeta = max(0, 0.5 - zeta_dr_current);
        % Approximate: delta_N_r ~ 2*delta_zeta*wn_dr
        % N_dr * kr adds to effective N_r
        if abs(N_dr) > 1e-10
            kr = 2 * delta_zeta * wn_dr / abs(N_dr);
        else
            kr = 0.5;
        end
    else
        kr = 0.5;
    end
end

gains.kr   = kr;
gains.p_wo = p_wo;

fprintf('\n--- Yaw Damper ---\n');
fprintf('  kr      = %.4f\n', kr);
fprintf('  p_wo    = %.2f rad/s\n', p_wo);

%% ---- Pitch attitude hold (inner longitudinal loop) ---------------------
% TF: theta(s)/de(s) = a_theta3 / (s^2 + a_theta1*s + a_theta2)
%
% PD controller: de = kp_theta*(theta_c - theta) - kd_theta*q
%   theta(s)/theta_c(s) = kp_theta*a_theta3 / (s^2 + (a_theta1+kd_theta*a_theta3)*s
%                                                + (a_theta2+kp_theta*a_theta3))
%
% Desired: s^2 + 2*zeta_theta*wn_theta*s + wn_theta^2

if isfield(design, 'wn_theta')
    wn_theta = design.wn_theta;
else
    % Beard's formula: wn_theta from max de for max theta error
    theta_max = deg2rad(10);   % max pitch error [rad]
    wn_theta = sqrt(lin.a_theta2 + abs(lin.a_theta3) * de_max / theta_max);
    % Ensure it's real and positive
    wn_theta = max(wn_theta, 1.0);
end

kp_theta = (wn_theta^2 - lin.a_theta2) / lin.a_theta3;
kd_theta = (2 * zeta_theta * wn_theta - lin.a_theta1) / lin.a_theta3;

gains.kp_theta = kp_theta;
gains.kd_theta = kd_theta;
gains.wn_theta = wn_theta;
gains.zeta_theta = zeta_theta;

% DC gain
K_theta_DC = kp_theta * lin.a_theta3 / wn_theta^2;
gains.K_theta_DC = K_theta_DC;

fprintf('\n--- Pitch Attitude Hold ---\n');
fprintf('  wn_theta = %.3f rad/s\n', wn_theta);
fprintf('  kp_theta = %.6f\n', kp_theta);
fprintf('  kd_theta = %.6f\n', kd_theta);
fprintf('  K_DC     = %.4f\n', K_theta_DC);

%% ---- Altitude hold (outer longitudinal loop) ---------------------------
% TF: h(s)/theta(s) = Va / s  (approximately)
%
% PI controller: theta_c = kp_h*(h_c - h) + ki_h*int(h_c - h)
%   h(s)/h_c(s) ~ (kp_h*Va*s + ki_h*Va) / (s^2 + kp_h*Va*s + ki_h*Va)
% (same form as course hold)
%
% Desired: wn_h and zeta_h

wn_h = wn_theta / W_h;
zeta_h = def('zeta_h', 1.5);

kp_h = 2 * zeta_h * wn_h / (K_theta_DC * Va);
ki_h = wn_h^2 / (K_theta_DC * Va);
 

gains.kp_h  = kp_h;
gains.ki_h  = ki_h;
gains.wn_h  = wn_h;
gains.zeta_h = zeta_h;

fprintf('\n--- Altitude Hold ---\n');
fprintf('  wn_h    = %.4f rad/s\n', wn_h);
fprintf('  kp_h    = %.6f\n', kp_h);
fprintf('  ki_h    = %.6f\n', ki_h);

%% ---- Summary -----------------------------------------------------------
fprintf('\n=== SLC Gains Summary ===\n');
fprintf('LATERAL:   kp_phi=%.4f, kd_phi=%.4f, kp_chi=%.4f, ki_chi=%.6f, kr=%.4f\n', ...
    kp_phi, kd_phi, kp_chi, ki_chi, kr);
fprintf('LONGIT:    kp_theta=%.4f, kd_theta=%.4f, kp_h=%.6f, ki_h=%.6f\n', ...
    kp_theta, kd_theta, kp_h, ki_h);

end

%% ---- Helper function ---------------------------------------------------
function val = set_default(s, field, default)
    if isfield(s, field)
        val = s.(field);
    else
        val = default;
    end
end
