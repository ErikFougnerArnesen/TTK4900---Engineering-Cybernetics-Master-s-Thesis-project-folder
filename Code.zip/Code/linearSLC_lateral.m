function [da, dr, phi_c_out, debug, state] = linearSLC_lateral(...
    chi_cmd, chi, phi, p_rate, r_rate, Vg, beta, params, gains, dt, state)
% LINEARSLC_LATERAL  Lateral SLC autopilot with gains from linearization.
%
%   Implements Beard & McLain Ch. 6.1.1 successive loop closure:
%     Inner  : roll attitude hold    phi_c -> da   (PD)
%     Outer  : course hold           chi_c -> phi_c (PI)
%     Indep. : yaw damper + beta     r,beta -> dr   (washout + proportional)
%
%   Gains are pre-computed from the linearized state-space model by
%   tomahawk_linearize() and tomahawk_slc_gains(), then passed in via
%   the 'gains' struct.  This separates the linear design (Beard Ch. 5)
%   from the nonlinear deployment (Beard Ch. 6).
%
%   Inputs:
%     chi_cmd : commanded course angle [rad]
%     chi     : current course angle [rad]
%     phi     : roll angle [rad]
%     p_rate  : roll rate [rad/s]
%     r_rate  : yaw rate [rad/s]
%     Va      : airspeed [m/s]
%     Vg      : ground speed [m/s]
%     beta    : sideslip angle [rad]
%     params  : parameter struct from tomahawk_params()
%     gains   : struct from tomahawk_slc_gains() with fields:
%               kp_phi, kd_phi, kp_chi, ki_chi, kr, p_wo
%     dt      : sampling time [s]
%     state   : persistent state struct (see initialization below)
%
%   Outputs:
%     da, dr     : aileron and rudder commands [rad]
%     phi_c_out  : commanded roll angle [rad] (for logging)
%     debug      : struct with internal signals
%     state      : updated state struct
%
%   State initialization (call before first use):
%     state.chi_ref    = initial_chi;
%     state.chidot_ref = 0;
%     state.chi_int    = 0;
%     state.y_wo       = 0;
%     state.r_prev     = 0;

% =========================================================================
% Design parameters (matching validated linear simulation)
% =========================================================================
phi_max    = deg2rad(35);       % max bank angle [rad]
da_max     = params.aileron_max;
dr_max     = params.rudder_max;

% Beta feedback gain (sideslip suppression)
k_beta = 1.0 * abs(params.Cn_beta / params.Cn_dr);

% =========================================================================
% Reference model for course command (2nd order, critically damped)
% =========================================================================
wn_ref   = 0.6;
zeta_ref = 1.0;
chidot_max = deg2rad(10);

% Wrap command to nearest angle from current reference
chi_cmd_wrapped = state.chi_ref + ssa(chi_cmd - state.chi_ref);

% 2nd order reference model integration
chi_ref_ddot = -2*zeta_ref*wn_ref*state.chidot_ref ...
               - wn_ref^2*(state.chi_ref - chi_cmd_wrapped);
state.chidot_ref = state.chidot_ref + dt * chi_ref_ddot;
state.chidot_ref = max(-chidot_max, min(chidot_max, state.chidot_ref));
state.chi_ref = state.chi_ref + dt * state.chidot_ref;

% =========================================================================
% Outer loop: course hold (PI)
% =========================================================================
e_chi = ssa(state.chi_ref - chi);

phi_c = gains.kp_chi * e_chi + gains.ki_chi * state.chi_int;

% Saturate bank angle
phi_c_sat = max(-phi_max, min(phi_max, phi_c));

% Anti-windup: integrate only when unsaturated or error is reducing
if abs(phi_c - phi_c_sat) < 1e-6 || (e_chi * state.chi_int < 0)
    state.chi_int = state.chi_int + dt * e_chi;
end

phi_c = phi_c_sat;

% =========================================================================
% Inner loop: roll attitude hold (PD)
% =========================================================================
e_phi = ssa(phi_c - phi);
da = gains.kp_phi * e_phi - gains.kd_phi * p_rate;

da = max(-da_max, min(da_max, da));

% =========================================================================
% Yaw damper (washout on r) + beta suppression
% =========================================================================
% Tustin discretization of H(s) = s/(s + p_wo)
alpha_wo = (2 - gains.p_wo * dt) / (2 + gains.p_wo * dt);
beta_wo  = 2 / (2 + gains.p_wo * dt);

y_wo_new = alpha_wo * state.y_wo + beta_wo * (r_rate - state.r_prev);
dr = gains.kr * y_wo_new - k_beta * beta;

dr = max(-dr_max, min(dr_max, dr));

% Update washout states
state.y_wo   = y_wo_new;
state.r_prev = r_rate;

% =========================================================================
% Outputs
% =========================================================================
phi_c_out = phi_c;

debug.e_chi   = e_chi;
debug.e_phi   = e_phi;
debug.chi_ref = state.chi_ref;
debug.phi_c   = phi_c;
debug.da      = da;
debug.dr      = dr;
debug.y_wo    = y_wo_new;
debug.k_beta  = k_beta;

end
