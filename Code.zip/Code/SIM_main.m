function SIM_main()
% Unified 6-DOF mission simulation with selectable autopilot.
%
%   Launches a GUI popup to choose between:
%     Mode 1 (SLC): Successive Loop Closure
%       - linearSLC_lateral.m    (course hold + roll + yaw damper + beta FB)
%       - linearSLC_longitudinal.m (altitude hold + pitch hold)
%       - Guidance: LOSchi (Fossen 2021, direct course command)
%
%     Mode 2 (LQR): Full-state LQR
%       - lqrLateralAutopilot.m   (heading tracking, simultaneous da + dr)
%       - lqrLongitudinalAutopilot.m (altitude tracking, elevator)
%       - Guidance: ALOSpsi + LOSobserver (Fossen 2023, heading command)
%
%     Mode 3 (LQR-LOSchi): Full-state LQR with course guidance
%       - lqrLateralAutopilot.m   (heading tracking, simultaneous da + dr)
%       - lqrLongitudinalAutopilot.m (altitude tracking, elevator)
%       - Guidance: LOSchi (Fossen 2021, course command), converted to a
%         heading command by subtracting the measured crab angle:
%             psi_cmd = chi_d - chi_c,   chi_c = chi - psi
%         This removes the steady-state heading bias that feeding chi_d
%         directly into the heading-tracking LQR would otherwise leave
%         under wind.
%
%   Both modes share:
%     - Nonlinear 6-DOF EOM (tomahawk_eom.m) integrated with RK4
%     - Linearization around trim (tomahawk_linearize.m)
%     - Waypoint mission definition (NED coordinates)
%     - Altitude interpolation along waypoint legs with terminal descent
%     - Turn-compensation feedforward for banked flight
%     - Dryden wind model (steady + turbulence, configurable)
%     - CPA termination (Siouris Sec 5.1) and impact analysis
%
%   Dependencies:
%     tomahawk_params.m, tomahawk_eom.m, tomahawk_trim.m
%     tomahawk_linearize.m, tomahawk_slc_gains.m, const_ctrl.m
%     linearSLC_lateral.m, linearSLC_longitudinal.m
%     lqrLateralDesign.m, lqrLateralAutopilot.m
%     lqrLongitudinalDesign.m, lqrLongitudinalAutopilot.m
%     ALOSpsi.m, LOSobserver.m, LOSchi.m
%     refModel.m, ssa.m
%     drydenWindInit.m, drydenWindModel.m
%
%   References:
%     Beard & McLain, "Small Unmanned Aircraft" (TTK 4190 lecture notes)
%     Fossen (2021), "Handbook of Marine Craft Hydrodynamics and Motion
%       Control", Wiley, 2nd ed.
%     Fossen (2023), "An Adaptive Line-of-Sight (ALOS) Guidance Law for
%       Path Following", IEEE TCST 31(6), 2887-2894.
%     Siouris (2004), "Missile Guidance and Control Systems", Springer.
%
%   Erik Fougner Arnesen, NTNU -- TTK 4190 / Master's Thesis, 2026
%   Supervisor: Prof. Thor I. Fossen

clearvars;
clear ALOSpsi LOSchi;       % reset persistent guidance states
close all;

% ==============================================================================
% CONTROL MODE SELECTION (GUI)
% ==============================================================================
[ControlFlag, WindFlag] = controlMethod();
switch ControlFlag
    case 1, modeName = 'SLC';
    case 2, modeName = 'LQR';
    case 3, modeName = 'LQR-LOSchi';
end
WIND_ENABLED = (WindFlag == 1);   % true = Dryden gusts on, false = calm air

% ==============================================================================
% VEHICLE MODEL, TRIM, LINEARIZATION
% ==============================================================================
p = tomahawk_params();
[alpha_t, de_trim, trim_info] = tomahawk_trim(p);
p.T_trim = trim_info.T_trim;

% Recompute T_trim for consistency at converged trim
qbar0  = 0.5 * p.rho0 * p.Va_trim^2;
CL_t   = polyval(p.CL_poly, alpha_t) + p.CL_de * de_trim;
CD_t   = polyval(p.CD_poly, alpha_t) + p.CD_de * de_trim;
CX_t   = -CD_t * cos(alpha_t) + CL_t * sin(alpha_t);
p.T_trim = -qbar0 * p.S * CX_t + p.mass * p.g * sin(alpha_t);

Va0 = p.Va_trim;
u0  = Va0 * cos(alpha_t);
w0  = Va0 * sin(alpha_t);

% --- Linearize around trim ---
x_trim = zeros(12,1);
x_trim(4) = u0;  x_trim(6) = w0;  x_trim(8) = alpha_t;
u_trim_vec = [de_trim; 0; 0];

fprintf('Linearizing around trim...\n');
lin = tomahawk_linearize(p, x_trim, u_trim_vec);
disp('A_lon ='); disp(lin.A_lon);
disp('B_lon ='); disp(lin.B_lon);

% ==============================================================================
% GAIN DESIGN (mode-dependent)
% ==============================================================================
switch ControlFlag
    case 1  % SLC
        design = struct();
        design.zeta_phi   = 0.9;
        design.wn_phi     = 2.0; 
        design.zeta_chi   = 2.0;
        design.W_chi      = 10;
        design.zeta_theta = 0.9;
        design.zeta_h     = 1.5;
        design.W_h        = 40; 

        gains = tomahawk_slc_gains(lin, design);

        % Set washout pole from dutch-roll frequency
        gains.p_wo = lin.dutch_roll.wn / 10;

        fprintf('  Washout pole: p_wo = %.3f rad/s (wn_dr/10)\n', gains.p_wo);
        fprintf('  Dutch roll:   wn = %.3f rad/s, zeta = %.4f\n', ...
            lin.dutch_roll.wn, lin.dutch_roll.zeta);

    case {2, 3}  % LQR (ALOSpsi heading guidance, or LOSchi course guidance)
        fprintf('\n--- Computing LQR gains from linearized model ---\n');
        [K_lat, lat_design] = lqrLateralDesign(lin);
        [K_lon, lon_design] = lqrLongitudinalDesign(lin);
end

% ==============================================================================
% WAYPOINT MISSION (NED, meters)
% ==============================================================================
wpt.pos.x = [    0;  20000;  40000;  60000;  80000; 100000;  110000];
wpt.pos.y = [    0;      0;      0;   5000;      0;      0;       0];
wpt.pos.z = [  500;    500;    500;    500;    500;    500;       0];

nWP = length(wpt.pos.x);

% ==============================================================================
% SIMULATION SETUP
% ==============================================================================
h_step = 0.01;              % sampling time [s]
h0     = wpt.pos.z(1);      % initial altitude [m]

% Simulation time from path length
leg_dists = sqrt(diff(wpt.pos.x).^2 + diff(wpt.pos.y).^2);
T_max     = 1.3 * sum(leg_dists) / Va0;
T_max     = ceil(T_max / 10) * 10;

% Final-leg approach direction
dx_final = wpt.pos.x(nWP) - wpt.pos.x(nWP-1);
dy_final = wpt.pos.y(nWP) - wpt.pos.y(nWP-1);
d_final  = sqrt(dx_final^2 + dy_final^2);
e_app    = [dx_final; dy_final] / d_final;

% Initial heading
psi0 = atan2(wpt.pos.y(2) - wpt.pos.y(1), ...
             wpt.pos.x(2) - wpt.pos.x(1));

% Initial state
x = [wpt.pos.x(1); wpt.pos.y(1); -h0; u0; 0; w0; 0; alpha_t; psi0; 0; 0; 0];

fprintf('Path length: %.1f km,  T_max = %.0f s\n', sum(leg_dists)/1000, T_max);

% ==============================================================================
% WIND MODEL
% ==============================================================================
dryden = drydenWindInit(h_step, Va0, 'med-light', [0; 0; 0]);

if WIND_ENABLED
    disp('Wind: Dryden gust model active (light-med turbulence, no steady wind)');
else
    disp('Wind: DISABLED (calm air, diagnostic baseline)');
end

% ==============================================================================
% GUIDANCE PARAMETERS (mode-dependent)
% ==============================================================================
switch ControlFlag
    case 1  % SLC: LOSchi (course guidance)
        Delta_h  = 2000;             % LOS lookahead distance [m]
        R_switch = 1000;             % waypoint switch radius [m]

        fprintf('Guidance: LOSchi, Delta_h = %d m, R_switch = %d m\n\n', ...
            Delta_h, R_switch);

    case 2  % LQR: ALOSpsi + LOSobserver (heading guidance)
        Delta_h  = 2000;             % LOS lookahead distance [m]
        R_switch = 1500;             % waypoint switch radius [m]
        K_f      = 0.5;              % LOSobserver gain
        gamma_h  = 0.00001;          % ALOS adaptive gain

        fprintf('Guidance: ALOSpsi + LOSobserver\n');
        fprintf('  Delta_h = %d m, R_switch = %d m\n', Delta_h, R_switch);
        fprintf('  K_f = %.2f, gamma_h = %.5f\n\n', K_f, gamma_h);

    case 3  % LQR + LOSchi (course guidance, crab-corrected to heading)
        Delta_h  = 2000;             % LOS lookahead distance [m]
        R_switch = 1500;             % waypoint switch radius [m]

        fprintf('Guidance: LOSchi (course) -> heading via crab correction\n');
        fprintf('  psi_cmd = chi_d - chi_c\n');
        fprintf('  Delta_h = %d m, R_switch = %d m\n\n', Delta_h, R_switch);
end

% ==============================================================================
% AUTOPILOT STATE INITIALIZATION
% ==============================================================================
switch ControlFlag
    case 1  % SLC
        lat_state.chi_ref    = psi0;
        lat_state.chidot_ref = 0;
        lat_state.chi_int    = 0;
        lat_state.y_wo       = 0;
        lat_state.r_prev     = 0;

        lon_state.h_ref    = h0;
        lon_state.hdot_ref = 0;
        lon_state.h_int    = 0;

    case 2  % LQR
        % LOSobserver states
        psi_d = psi0;
        r_d   = 0;

        ap_lat.psi_int = 0;
        ap_lat.psi_d   = psi0;

        ap_lon.h_int = 0;

        % Altitude reference model states and parameters
        h_ref      = h0;
        hdot_ref   = 0;
        h_a_ref    = 0;
        wn_h_ref   = 1.0;
        zeta_h_ref = 1.0;
        hdot_max   = 80;

    case 3  % LQR + LOSchi
        ap_lat.psi_int = 0;
        ap_lat.psi_d   = psi0;

        ap_lon.h_int = 0;

        % Altitude reference model states and parameters
        h_ref      = h0;
        hdot_ref   = 0;
        h_a_ref    = 0;
        wn_h_ref   = 1.0;
        zeta_h_ref = 1.0;
        hdot_max   = 80;
end

% ==============================================================================
% DATA LOGGING
% ==============================================================================
N_max   = ceil(T_max / h_step) + 1;
nCols   = 39;   % 35 base + 3 commanded deflections + 1 raw altitude command (h_cmd_raw)
simData = zeros(N_max, nCols);
k_log   = 0;

% ==============================================================================
% MAIN SIMULATION LOOP
% ==============================================================================
t = 0;
term_reason = 'T_max reached';

% --- Actuator dynamics (first-order lag, common to all modes) ---
% Control surfaces track autopilot commands with first-order lag.
% Discretized via exact ZOH (A&W Sec. 2.3, Eqs. 2.4-2.5).
tau_act = 0.05;                      % actuator time constant [s]; cite source
phi_act = exp(-h_step / tau_act);    % ZOH pole
de_act  = de_trim;                   % elevator starts at trim deflection
da_act  = 0;                         % aileron starts at zero
dr_act  = 0;                         % rudder starts at zero

for i = 1:N_max
    % --- Unpack state ---
    pn_now = x(1);  pe_now = x(2);  pd = x(3);
    u_b  = x(4);   v_b  = x(5);  w_b  = x(6);
    phi  = x(7);   theta = x(8); psi  = x(9);
    p_rate = x(10); q = x(11);   r_rate = x(12);
    h_cur = -pd;

    % --- Divergence check ---
    if any(isnan(x)) || any(abs(x) > 1e10)
        fprintf('  DIVERGED at t = %.2f s\n', t);
        term_reason = 'Divergence';
        break;
    end

    % --- Wind ---
    [wind_b, ~, dryden] = drydenWindModel(dryden, phi, theta, psi);
    if ~WIND_ENABLED
        wind_b = [0; 0; 0];   % gate at output: Dryden state still advances
    end

    % --- Airmass-relative velocity ---
    ur = u_b - wind_b(1);
    vr = v_b - wind_b(2);
    wr = w_b - wind_b(3);
    Va    = max(sqrt(ur^2 + vr^2 + wr^2), 1);
    alpha = atan2(wr, ur);
    beta  = asin(max(-1, min(1, vr / Va)));

    % --- Ground speed and course angle ---
    cpsi = cos(psi); spsi = sin(psi);
    cth  = cos(theta); sth = sin(theta);
    sphi = sin(phi);   cphi = cos(phi);

    pn_dot = cth*cpsi*u_b + (sphi*sth*cpsi - cphi*spsi)*v_b ...
           + (cphi*sth*cpsi + sphi*spsi)*w_b;
    pe_dot = cth*spsi*u_b + (sphi*sth*spsi + cphi*cpsi)*v_b ...
           + (cphi*sth*spsi - sphi*cpsi)*w_b;
    chi = atan2(pe_dot, pn_dot);
    Vg  = max(sqrt(pn_dot^2 + pe_dot^2), 1);

    % --- Wind triangle diagnostics (Beard Ch. 2.4) ---
    pd_dot  = -sth*u_b + sphi*cth*v_b + cphi*cth*w_b;
    h_dot   = -pd_dot;
    gamma_a = theta - alpha;
    Vg_h    = sqrt(pn_dot^2 + pe_dot^2);
    gamma   = atan2(-pd_dot, Vg_h);
    chi_c   = ssa(chi - psi);

    % ======================================================================
    % GUIDANCE AND CONTROL (mode-dependent)
    % ======================================================================
    switch ControlFlag
        case 1  % ----- SLC -----
            % LOSchi guidance (course command)
            [chi_d, y_e, k_active] = LOSchi(pn_now, pe_now, Delta_h, R_switch, wpt);
            k_active = max(k_active, 1);

            % Altitude command (interpolation along all legs, including terminal)
            k_next  = min(k_active + 1, nWP);
            x1 = wpt.pos.x(k_active);   y1 = wpt.pos.y(k_active);
            x2 = wpt.pos.x(k_next);     y2 = wpt.pos.y(k_next);
            leg_len = sqrt((x2-x1)^2 + (y2-y1)^2);
            if leg_len > 1
                frac = ((pn_now-x1)*(x2-x1) + (pe_now-y1)*(y2-y1)) / leg_len^2;
                frac = max(0, min(1, frac));
            else
                frac = 1;
            end
            h1 = wpt.pos.z(k_active);
            h2 = wpt.pos.z(k_next);
            h_cmd = h1 + frac * (h2 - h1);
            h_cmd_raw = h_cmd;   % raw interpolated command (SLC tracks this directly)

            % Lateral autopilot (course tracking)
            [da, dr, phi_c, ~, lat_state] = linearSLC_lateral(...
                chi_d, chi, phi, p_rate, r_rate, Vg, beta, ...
                p, gains, h_step, lat_state);

            % Longitudinal autopilot (altitude tracking)
            [de_pert, theta_c, ~, lon_state] = linearSLC_longitudinal(...
                h_cmd, h_cur, theta, q, p, gains, h_step, ...
                lon_state, alpha_t, phi);

            % Elevator: trim + perturbation
            de_total = de_trim + de_pert;
            de_total = max(-p.elevon_max, min(p.elevon_max, de_total));

            % Logging variables (SLC-specific)
            phi_d   = phi_c;
            theta_d = theta_c;
            psi_ref_or_chi_d = chi_d;                  % guidance raw command
            psi_d_or_chi_ref = lat_state.chi_ref;       % reference model output
            beta_c_hat = 0;      % not used in SLC

        case 2  % ----- LQR -----
            % ALOSpsi guidance (heading command)
            [psi_ref, y_e, beta_c_hat, k_active] = ALOSpsi( ...
                pn_now, pe_now, Delta_h, gamma_h, h_step, R_switch, wpt);

            % LOSobserver: smooth heading command at waypoint switches
            [psi_d, r_d] = LOSobserver(psi_d, r_d, psi_ref, h_step, K_f);
            psi_cmd = psi_d;

            % Altitude command (linear interpolation along all legs)
            k = k_active;
            xk  = wpt.pos.x(k);       yk  = wpt.pos.y(k);
            if k < nWP
                xkn = wpt.pos.x(k+1); ykn = wpt.pos.y(k+1);
            else
                xkn = wpt.pos.x(nWP); ykn = wpt.pos.y(nWP);
            end
            pi_h   = atan2(ykn - yk, xkn - xk);
            x_e_at = (pn_now - xk) * cos(pi_h) + (pe_now - yk) * sin(pi_h);
            d_leg  = sqrt((xkn - xk)^2 + (ykn - yk)^2);

            frac  = max(0, min(1, x_e_at / max(d_leg, 1)));
            h_cmd = wpt.pos.z(k) + frac * (wpt.pos.z(min(k+1, nWP)) - wpt.pos.z(k));
            h_cmd_raw = h_cmd;   % raw interpolated command (before reference-model smoothing)

            % Smooth altitude command through reference model
            [h_ref, hdot_ref, h_a_ref] = refModel( ...
                h_ref, hdot_ref, h_a_ref, ...
                h_cmd, hdot_max, zeta_h_ref, wn_h_ref, h_step, 0);
            h_cmd = h_ref;   % overwrite with smoothed command

            % LQR lateral autopilot (heading tracking)
            [da, dr, ~, ap_lat] = lqrLateralAutopilot( ...
                psi_cmd, psi, phi, vr, p_rate, r_rate, K_lat, p, h_step, ap_lat);

            % LQR longitudinal autopilot (altitude tracking)
            [de_total, ~, ap_lon] = lqrLongitudinalAutopilot( ...
                h_cmd, h_cur, u_b, w_b, q, theta, phi, wind_b, ...
                K_lon, p, alpha_t, de_trim, h_step, ap_lon);

            % Re-saturate at physical limits
            de_total = max(-p.elevon_max,  min(p.elevon_max,  de_total));
            da       = max(-p.aileron_max, min(p.aileron_max, da));
            dr       = max(-p.rudder_max,  min(p.rudder_max,  dr));

            % Logging variables (LQR-specific)
            phi_d   = 0;              % LQR has no explicit phi_d
            gamma_ref = asin( max(-1, min(1, hdot_ref / Va)) );
            theta_d   = gamma_ref + alpha_t;   % pitch implied by altitude ref model
            psi_ref_or_chi_d = psi_ref;    % ALOSpsi raw command
            psi_d_or_chi_ref = psi_d;      % LOSobserver output
            beta_c_hat = beta_c_hat;  %#ok  % ALOS crab estimate

        case 3  % ----- LQR + LOSchi (crab-corrected) -----
            % LOSchi guidance (course command)
            [chi_d, y_e, k_active] = LOSchi(pn_now, pe_now, Delta_h, R_switch, wpt);
            k_active = max(k_active, 1);

            % Convert course command to heading command by subtracting the
            % measured crab angle:  psi_cmd = chi_d - chi_c,  chi_c = chi - psi.
            % In steady wind, holding this psi makes the achieved course equal
            % chi_d, removing the bias that psi_cmd = chi_d would leave.
            psi_cmd = ssa(chi_d - chi_c);

            % Altitude command (interpolation along all legs, incl. terminal)
            k_next  = min(k_active + 1, nWP);
            x1 = wpt.pos.x(k_active);   y1 = wpt.pos.y(k_active);
            x2 = wpt.pos.x(k_next);     y2 = wpt.pos.y(k_next);
            leg_len = sqrt((x2-x1)^2 + (y2-y1)^2);
            if leg_len > 1
                frac = ((pn_now-x1)*(x2-x1) + (pe_now-y1)*(y2-y1)) / leg_len^2;
                frac = max(0, min(1, frac));
            else
                frac = 1;
            end
            h_cmd = wpt.pos.z(k_active) + frac * (wpt.pos.z(k_next) - wpt.pos.z(k_active));
            h_cmd_raw = h_cmd;   % raw interpolated command (before reference-model smoothing)

            % Smooth altitude command through reference model
            [h_ref, hdot_ref, h_a_ref] = refModel( ...
                h_ref, hdot_ref, h_a_ref, ...
                h_cmd, hdot_max, zeta_h_ref, wn_h_ref, h_step, 0);
            h_cmd = h_ref;   % overwrite with smoothed command

            % LQR lateral autopilot (heading tracking)
            [da, dr, ~, ap_lat] = lqrLateralAutopilot( ...
                psi_cmd, psi, phi, vr, p_rate, r_rate, K_lat, p, h_step, ap_lat);

            % LQR longitudinal autopilot (altitude tracking)
            [de_total, ~, ap_lon] = lqrLongitudinalAutopilot( ...
                h_cmd, h_cur, u_b, w_b, q, theta, phi, wind_b, ...
                K_lon, p, alpha_t, de_trim, h_step, ap_lon);

            % Re-saturate at physical limits
            de_total = max(-p.elevon_max,  min(p.elevon_max,  de_total));
            da       = max(-p.aileron_max, min(p.aileron_max, da));
            dr       = max(-p.rudder_max,  min(p.rudder_max,  dr));

            % Logging variables (LQR-LOSchi specific)
            phi_d   = 0;              % LQR has no explicit phi_d
            gamma_ref = asin( max(-1, min(1, hdot_ref / Va)) );
            theta_d   = gamma_ref + alpha_t;   % pitch implied by altitude ref model
            psi_ref_or_chi_d = chi_d;      % LOSchi raw course command
            psi_d_or_chi_ref = psi_cmd;    % crab-corrected heading command
            beta_c_hat = chi_c;            % log measured crab for diagnostics
    end

    % --- First-order actuator dynamics (command -> actual deflection) ---
    % de_total, da, dr are the SATURATED commanded deflections from the
    % autopilot. Physical surfaces track these with first-order lag,
    % discretized via exact ZOH (A&W Sec. 2.3). The actual deflections
    % de_act/da_act/dr_act are what drive the plant and what we log.
    de_act = phi_act * de_act + (1 - phi_act) * de_total;
    da_act = phi_act * da_act + (1 - phi_act) * da;
    dr_act = phi_act * dr_act + (1 - phi_act) * dr;

    % Re-saturate the ACTUAL deflection at physical travel limits
    de_act = max(-p.elevon_max,  min(p.elevon_max,  de_act));
    da_act = max(-p.aileron_max, min(p.aileron_max, da_act));
    dr_act = max(-p.rudder_max,  min(p.rudder_max,  dr_act));

    % --- Store simulation data ---
    k_log = k_log + 1;
    simData(k_log, 1:38) = [x', de_act, da_act, dr_act, ...
                         h_cmd, psi_ref_or_chi_d, psi_d_or_chi_ref, ...
                         phi_d, theta_d, ...
                         wind_b', Va, alpha, beta, chi, Vg, ...
                         gamma_a, gamma, chi_c, h_dot, ...
                         y_e, beta_c_hat, k_active, ...
                         de_total, da, dr];   % cols 36-38: commanded deflections
    simData(k_log, 39) = h_cmd_raw;   % col 39: raw interpolated altitude command

    % --- Ground impact check ---
    if h_cur <= 0 && t > 1
        fprintf('  Ground impact at t = %.1f s\n', t);
        term_reason = 'Ground impact';
        break;
    end

    % --- CPA termination (Siouris Sec 5.1) ---
    dp = [pn_now - wpt.pos.x(nWP); pe_now - wpt.pos.y(nWP)];
    along_track = e_app' * dp;
    if along_track > 0 && k_active >= nWP - 1
        term_reason = 'Target reached';
        break;
    end

    % --- RK4 integration of nonlinear EOM with wind ---
    ctrl = @(~, ~) deal(de_act, da_act, dr_act);
    x = rk4_wind(h_step, t, x, p, ctrl, wind_b);

    t = t + h_step;
end

% ==============================================================================
% EXTRACT LOGGED DATA
% ==============================================================================
simData = simData(1:k_log, :);

t_vec   = (0:k_log-1)' * h_step;
pn      = simData(:,1);   pe      = simData(:,2);   pd  = simData(:,3);
u_v     = simData(:,4);   v_v     = simData(:,5);   w_v = simData(:,6);
phi_v   = simData(:,7);   th      = simData(:,8);   psi_v = simData(:,9);
pp      = simData(:,10);  q_v     = simData(:,11);  r_v   = simData(:,12);
de_log  = simData(:,13);  da_log  = simData(:,14);  dr_log = simData(:,15);
de_cmd_log = simData(:,36); da_cmd_log = simData(:,37); dr_cmd_log = simData(:,38);

h_cmd_log    = simData(:,16);
h_cmd_raw_log = simData(:,39);   % raw interpolated command (Option A reference)
cmd1_log     = simData(:,17);    % SLC: chi_d (LOSchi), LQR: psi_ref (ALOSpsi)
cmd2_log     = simData(:,18);    % SLC: chi_ref (ref model), LQR: psi_d (LOSobserver)
phi_d_log    = simData(:,19);
theta_d_log  = simData(:,20);

Va_log       = simData(:,24);
alpha_log    = simData(:,25);
beta_log     = simData(:,26);
chi_log      = simData(:,27);
Vg_log       = simData(:,28);
gamma_a_log  = simData(:,29);
gamma_log    = simData(:,30);
chi_c_log    = simData(:,31);
h_dot_log    = simData(:,32);

y_e_log      = simData(:,33);
beta_c_log   = simData(:,34);
k_active_log = simData(:,35);

alt   = -pd;
t_end = t_vec(end);

fprintf('\nTermination: %s at t = %.2f s\n', term_reason, t_end);
fprintf('Final waypoint reached: %d / %d\n', max(k_active_log), nWP);

% ==============================================================================
% PLOTS
% ==============================================================================
lw = 1.3;
legendLocation = 'best';

% --------------------------------------------------------------------------
% Figure 1: Ground track with waypoints (2-D)
% --------------------------------------------------------------------------
figure('Name', 'Ground Track', 'Position', [50 400 600 600]);
plot(wpt.pos.y/1000, wpt.pos.x/1000, 'k--', 'LineWidth', 1); hold on;
plot(wpt.pos.y/1000, wpt.pos.x/1000, 'ko', 'MarkerSize', 8, ...
    'MarkerFaceColor', [0.9 0.9 0.9]);
for iw = 1:nWP
    text(wpt.pos.y(iw)/1000 + 0.3, wpt.pos.x(iw)/1000, ...
        sprintf('WP%d (%dm)', iw, wpt.pos.z(iw)), 'FontSize', 9);
end
plot(pe/1000, pn/1000, 'b', 'LineWidth', 1.5);
plot(pe(1)/1000, pn(1)/1000, 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
plot(pe(end)/1000, pn(end)/1000, 'rs', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
grid on; axis equal;
xlabel('East  [km]'); ylabel('North  [km]');
title(sprintf('Ground track with waypoint guidance (%s)', modeName));
legend('Path segments', 'Waypoints', 'Trajectory', 'Start', 'End', ...
    'Location', legendLocation);

% --------------------------------------------------------------------------
% Figure 2: 3-D trajectory
% --------------------------------------------------------------------------
figure('Name', '3D Trajectory', 'Position', [670 400 600 400]);
plot3(pe/1000, pn/1000, alt, 'b', 'LineWidth', 1.5); hold on;
plot3(wpt.pos.y/1000, wpt.pos.x/1000, wpt.pos.z, 'ko', ...
    'MarkerSize', 8, 'MarkerFaceColor', [0.9 0.9 0.9]);
plot3(wpt.pos.y/1000, wpt.pos.x/1000, wpt.pos.z, 'k--', 'LineWidth', 0.8);
for iw = 1:nWP
    text(wpt.pos.y(iw)/1000, wpt.pos.x(iw)/1000, wpt.pos.z(iw) + 15, ...
        sprintf('WP%d', iw), 'FontSize', 9);
end
plot3(pe(1)/1000, pn(1)/1000, alt(1), 'go', ...
    'MarkerSize', 8, 'MarkerFaceColor', 'g');
grid on;
xlabel('East [km]'); ylabel('North [km]'); zlabel('Altitude [m]');
title(sprintf('3-D flight path (%s)', modeName));
view([-30 25]);

% --------------------------------------------------------------------------
% Figure 3: Guidance and path following (mode-specific)
% --------------------------------------------------------------------------
figure('Name', 'Guidance & Path Following', 'Position', [50 50 950 550]);

subplot(2,2,1);
plot(t_vec, y_e_log, 'b', 'LineWidth', lw); hold on;
yline(0, 'k--'); grid on;
xlabel('Time [s]'); ylabel('y_e  [m]'); title('Cross-track error');

subplot(2,2,2);
plot(t_vec, k_active_log, 'b', 'LineWidth', lw); grid on;
xlabel('Time [s]'); ylabel('k');
ylim([0.5, nWP + 0.5]); yticks(1:nWP);
title('Active waypoint index');

subplot(2,2,3);
switch ControlFlag
    case 1  % SLC: course pipeline
        plot(t_vec, rad2deg(cmd1_log), 'r--', 'LineWidth', 1); hold on;
        plot(t_vec, rad2deg(cmd2_log), 'Color', [0.8 0.4 0], 'LineWidth', 1);
        plot(t_vec, rad2deg(chi_log),  'b', 'LineWidth', lw);
        grid on; ylabel('[deg]'); xlabel('Time [s]');
        title('Course guidance pipeline');
        legend('\chi_{d} (LOSchi)', '\chi_{ref} (ref model)', ...
               '\chi (actual)', 'Location', legendLocation);
    case 2  % LQR: heading pipeline
        plot(t_vec, rad2deg(cmd1_log), 'r--', 'LineWidth', 1); hold on;
        plot(t_vec, rad2deg(cmd2_log), 'b', 'LineWidth', lw);
        plot(t_vec, rad2deg(psi_v),    'Color', [0 0.6 0], 'LineWidth', lw);
        grid on; ylabel('[deg]'); xlabel('Time [s]');
        title('Guidance pipeline');
        legend('\psi_{ref} (ALOS)', '\psi_d (LOSobserver)', ...
               '\psi (actual)', 'Location', legendLocation);
    case 3  % LQR-LOSchi: course command -> heading command pipeline
        plot(t_vec, rad2deg(cmd1_log), 'r--', 'LineWidth', 1); hold on;
        plot(t_vec, rad2deg(cmd2_log), 'b', 'LineWidth', lw);
        plot(t_vec, rad2deg(psi_v),    'Color', [0 0.6 0], 'LineWidth', lw);
        plot(t_vec, rad2deg(chi_log),  'm', 'LineWidth', 0.8);
        grid on; ylabel('[deg]'); xlabel('Time [s]');
        title('Guidance pipeline');
        legend('\chi_d (LOSchi)', '\psi_{cmd} (\chi_d - \chi_c)', ...
               '\psi (actual)', '\chi (course)', 'Location', legendLocation);
end

subplot(2,2,4);
switch ControlFlag
    case 1
        plot(t_vec, rad2deg(chi_c_log), 'b', 'LineWidth', lw); grid on;
        xlabel('Time [s]'); ylabel('\chi_c  [deg]');
        title('Crab angle  \chi_c = \chi - \psi');
    case 2
        plot(t_vec, rad2deg(beta_c_log), 'r', 'LineWidth', lw); hold on;
        plot(t_vec, rad2deg(chi_c_log),  'b', 'LineWidth', lw); grid on;
        xlabel('Time [s]'); ylabel('[deg]');
        title('Crab angle: ALOS estimate vs measured');
        legend('\beta_{hat} (ALOS)', '\chi_c (measured)', ...
               'Location', legendLocation);
    case 3
        plot(t_vec, rad2deg(chi_c_log), 'b', 'LineWidth', lw); grid on;
        xlabel('Time [s]'); ylabel('\chi_c  [deg]');
        title('Crab angle  \chi_c = \chi - \psi  (subtracted from \chi_d)');
end

switch ControlFlag
    case 1
        sgtitle('Guidance: LOSchi (Fossen 2021)', ...
            'FontSize', 13, 'FontWeight', 'bold');
    case 2
        sgtitle('Guidance: ALOSpsi + LOSobserver', ...
            'FontSize', 13, 'FontWeight', 'bold');
    case 3
        sgtitle('Guidance: LOSchi (course) + crab correction', ...
            'FontSize', 13, 'FontWeight', 'bold');
end

% --------------------------------------------------------------------------
% Figure 4: Autopilot tracking (mode-specific)
% --------------------------------------------------------------------------
figure('Name', 'Autopilot Tracking', 'Position', [50 50 950 550]);

subplot(2,2,1);
switch ControlFlag
    case 1  % SLC: course tracking
        plot(t_vec, rad2deg(cmd1_log), 'r--', 'LineWidth', 1); hold on;
        plot(t_vec, rad2deg(cmd2_log), 'Color', [0.8 0.4 0], 'LineWidth', 1);
        plot(t_vec, rad2deg(chi_log), 'b', 'LineWidth', lw);
        grid on; ylabel('\chi  [deg]'); xlabel('Time [s]');
        title('Course tracking');
        legend('Command', 'Ref model', 'Actual', 'Location', legendLocation);
    case 2  % LQR: heading tracking
        plot(t_vec, rad2deg(cmd1_log), 'r--', 'LineWidth', 1); hold on;
        plot(t_vec, rad2deg(cmd2_log), 'b', 'LineWidth', lw);
        plot(t_vec, rad2deg(psi_v), 'Color', [0 0.6 0], 'LineWidth', lw);
        grid on; ylabel('\psi  [deg]'); xlabel('Time [s]');
        title('Heading tracking');
        legend('\psi_{ref}', '\psi_d', '\psi', 'Location', legendLocation);
    case 3  % LQR-LOSchi: heading tracking (command from crab-corrected course)
        plot(t_vec, rad2deg(cmd1_log), 'r--', 'LineWidth', 1); hold on;
        plot(t_vec, rad2deg(cmd2_log), 'b', 'LineWidth', lw);
        plot(t_vec, rad2deg(psi_v), 'Color', [0 0.6 0], 'LineWidth', lw);
        grid on; ylabel('\psi  [deg]'); xlabel('Time [s]');
        title('Heading tracking');
        legend('\chi_d', '\psi_{cmd}', '\psi', 'Location', legendLocation);
end

subplot(2,2,2);
plot(t_vec, h_cmd_log, 'r--', 'LineWidth', 1); hold on;
plot(t_vec, alt, 'b', 'LineWidth', lw);
grid on; ylabel('h  [m]'); xlabel('Time [s]');
title('Altitude tracking');
legend('Command', 'Actual', 'Location', legendLocation);

subplot(2,2,3);
if ControlFlag == 1
    plot(t_vec, rad2deg(phi_d_log), 'r--', 'LineWidth', 1); hold on;
end
plot(t_vec, rad2deg(phi_v), 'b', 'LineWidth', lw);
grid on; ylabel('\phi  [deg]'); xlabel('Time [s]');
title('Roll angle');
if ControlFlag == 1
    legend('\phi_d', '\phi', 'Location', legendLocation);
end

subplot(2,2,4);
if ControlFlag == 1
    plot(t_vec, rad2deg(theta_d_log), 'r--', 'LineWidth', 1); hold on;
end
plot(t_vec, rad2deg(th), 'b', 'LineWidth', lw);
grid on; ylabel('\theta  [deg]'); xlabel('Time [s]');
title('Pitch angle');
if ControlFlag == 1
    legend('\theta_d', '\theta', 'Location', legendLocation);
end
sgtitle(sprintf('Autopilot Tracking (%s)', modeName), ...
    'FontSize', 13, 'FontWeight', "bold");
% --------------------------------------------------------------------------
% Figure 4b: Altitude tracking error w.r.t. raw waypoint altitude command
% Common reference across all modes (Option A): the raw interpolated command
% h_cmd_raw, before any reference-model smoothing. For Modes 2 and 3 this
% includes the reference-model lag in the measured error, so all three modes
% are judged against the same waypoint-derived altitude profile.
% --------------------------------------------------------------------------
h_err = h_cmd_raw_log - alt;   % altitude error w.r.t. raw waypoint command [m]

figure('Name', 'Altitude Error', 'Position', [120 60 700 400]);
plot(t_vec, h_err, 'b', 'LineWidth', lw); hold on;
yline(0, 'k--');
grid on; ylabel('h_{cmd} - h  [m]'); xlabel('Time [s]');
title(sprintf('Altitude tracking error (%s)', modeName));
legend(sprintf('STD = %.2f m', std(h_err)), ...
    'Location', legendLocation);

% --------------------------------------------------------------------------
% Figure 5: Control surfaces and angular rates
% --------------------------------------------------------------------------
figure('Name', 'Control Surfaces & Rates', 'Position', [100 50 1050 550]);

subplot(2,3,1);
plot(t_vec, rad2deg(de_cmd_log), 'r', 'LineWidth', 0.8); hold on;
plot(t_vec, rad2deg(de_log), 'b', 'LineWidth', lw);
yline( rad2deg(p.elevon_max), 'k:');
yline(-rad2deg(p.elevon_max), 'k:');
grid on; ylabel('\delta_e [deg]'); xlabel('Time [s]');
title('Elevator'); legend('commanded', 'actual', 'Location', 'best');

subplot(2,3,2);
plot(t_vec, rad2deg(da_cmd_log), 'r', 'LineWidth', 0.8); hold on;
plot(t_vec, rad2deg(da_log), 'b', 'LineWidth', lw);
yline( rad2deg(p.aileron_max), 'k:');
yline(-rad2deg(p.aileron_max), 'k:');
grid on; ylabel('\delta_a [deg]'); xlabel('Time [s]');
title('Aileron'); legend('commanded', 'actual', 'Location', 'best');

subplot(2,3,3);
plot(t_vec, rad2deg(dr_cmd_log), 'r', 'LineWidth', 0.8); hold on;
plot(t_vec, rad2deg(dr_log), 'b', 'LineWidth', lw);
yline( rad2deg(p.rudder_max), 'k:');
yline(-rad2deg(p.rudder_max), 'k:');
grid on; ylabel('\delta_r [deg]'); xlabel('Time [s]');
title('Rudder'); legend('commanded', 'actual', 'Location', 'best');

subplot(2,3,4);
plot(t_vec, rad2deg(pp), 'b', 'LineWidth', 0.8); grid on;
xlabel('Time [s]'); ylabel('p [deg/s]'); title('Roll rate');

subplot(2,3,5);
plot(t_vec, rad2deg(q_v), 'b', 'LineWidth', 0.8); grid on;
xlabel('Time [s]'); ylabel('q [deg/s]'); title('Pitch rate');

subplot(2,3,6);
plot(t_vec, rad2deg(r_v), 'b', 'LineWidth', 0.8); grid on;
xlabel('Time [s]'); ylabel('r [deg/s]'); title('Yaw rate');

sgtitle(sprintf('Control Surfaces & Angular Rates (%s)', modeName), ...
    'FontSize', 13, 'FontWeight', 'bold');

% --------------------------------------------------------------------------
% Figure 6: Aerodynamics and wind triangle
% --------------------------------------------------------------------------
figure('Name', 'Aerodynamics & Wind Triangle', 'Position', [150 50 950 550]);

subplot(2,2,1);
plot(t_vec, rad2deg(alpha_log), 'b', 'LineWidth', lw); hold on;
plot(t_vec, rad2deg(beta_log), 'r', 'LineWidth', lw); grid on;
xlabel('Time [s]'); ylabel('[deg]');
title('Angle of attack and sideslip');
legend('\alpha', '\beta', 'Location', legendLocation);

subplot(2,2,2);
plot(t_vec, Va_log, 'b', 'LineWidth', lw); hold on;
plot(t_vec, Vg_log, 'r', 'LineWidth', lw); grid on;
xlabel('Time [s]'); ylabel('[m/s]');
title('Airspeed vs ground speed');
legend('V_a', 'V_g', 'Location', legendLocation);

subplot(2,2,3);
plot(t_vec, rad2deg(gamma_a_log), 'b', 'LineWidth', lw); hold on;
plot(t_vec, rad2deg(gamma_log), 'r', 'LineWidth', lw); grid on;
xlabel('Time [s]'); ylabel('[deg]');
title('Flight path angles');
legend('\gamma_a = \theta - \alpha', '\gamma (inertial)', ...
       'Location', legendLocation);

subplot(2,2,4);
plot(t_vec, h_dot_log, 'b', 'LineWidth', lw); grid on;
xlabel('Time [s]'); ylabel('[m/s]');
title('Climb rate  dh/dt');
yline(0, 'k--');

sgtitle('Aerodynamics & Wind Triangle (Beard & McLain Ch. 2.4)', ...
    'FontSize', 13, 'FontWeight', 'bold');

% ==============================================================================
% SUMMARY STATISTICS AND IMPACT ANALYSIS
% ==============================================================================
fprintf('\nFigures generated.\n\n');
fprintf('Key metrics:\n');
fprintf('  Mean airspeed        : %.1f m/s\n', mean(Va_log));
fprintf('  Mean ground speed    : %.1f m/s\n', mean(Vg_log));
fprintf('  Altitude std dev     : %.2f m\n', std(alt - h_cmd_log));
fprintf('  Angle of attack max  : %.2f deg\n', max(abs(rad2deg(alpha_log))));
fprintf('  Sideslip std dev     : %.2f deg\n', std(rad2deg(beta_log)));
fprintf('  Sideslip max         : %.2f deg\n', max(abs(rad2deg(beta_log))));
fprintf('  Final position       : pn=%.0f m,  pe=%.0f m\n', pn(end), pe(end));
fprintf('  Max |roll|           : %.2f deg\n', max(abs(rad2deg(phi_v))));
fprintf('  Max |pitch|          : %.2f deg\n', max(abs(rad2deg(th))));

fprintf('\n--- Control effort ---\n');
fprintf('  Max |Aileron|        : %.2f deg\n', max(abs(rad2deg(da_log))));
fprintf('  Max |Elevator|       : %.2f deg\n', max(abs(rad2deg(de_log))));
fprintf('  Max |Rudder|         : %.2f deg\n', max(abs(rad2deg(dr_log))));

fprintf('\n--- Wind triangle ---\n');
fprintf('  Mean crab angle      : %.2f deg\n', mean(rad2deg(chi_c_log)));
fprintf('  Mean gamma_a         : %.3f deg\n', mean(rad2deg(gamma_a_log)));
fprintf('  Mean gamma           : %.3f deg\n', mean(rad2deg(gamma_log)));
fprintf('  Mean h_dot           : %.3f m/s\n', mean(h_dot_log));

fprintf('\n--- Guidance ---\n');
fprintf('  Final y_e            : %.1f m\n', y_e_log(end));
idx_last30 = t_vec >= max(0, t_end - 30);
fprintf('  RMS y_e (last 30 s)  : %.1f m\n', rms(y_e_log(idx_last30)));
fprintf('  Max |y_e|            : %.1f m\n', max(abs(y_e_log)));
fprintf('  Waypoints reached    : %d / %d\n', max(k_active_log), nWP);

% --- Impact analysis ---
pn_target = wpt.pos.x(nWP);
pe_target = wpt.pos.y(nWP);
h_target  = wpt.pos.z(nWP);

miss_north = pn(end) - pn_target;
miss_east  = pe(end) - pe_target;
miss_horiz = sqrt(miss_north^2 + miss_east^2);
miss_vert  = alt(end) - h_target;
miss_3d    = sqrt(miss_horiz^2 + miss_vert^2);

dp_final   = [miss_north; miss_east];
miss_along = e_app' * dp_final;
miss_cross = [-e_app(2); e_app(1)]' * dp_final;

fprintf('\n--- Impact analysis ---\n');
fprintf('  Termination          : %s\n', term_reason);
fprintf('  Flight time          : %.2f s\n', t_end);
fprintf('  Miss along-track     : %+.2f m\n', miss_along);
fprintf('  Miss cross-track     : %+.2f m\n', miss_cross);
fprintf('  Miss horizontal      : %.2f m\n', miss_horiz);
fprintf('  Miss vertical        : %+.2f m\n', miss_vert);

% --- CEP table row ---
fprintf('\n--- CEP table row ---\n');
fprintf('  %s | Delta_h=%d | miss_N=%+.2f | miss_E=%+.2f | miss_horiz=%.2f | miss_vert=%+.2f\n', ...
    modeName, Delta_h, miss_north, miss_east, miss_horiz, miss_vert);

fprintf('\nDone.\n');

end % SIM_tomahawk

% ==============================================================================
% LOCAL FUNCTIONS
% ==============================================================================

function [ControlFlag, WindFlag] = controlMethod()

    f = figure('Position', [400, 400, 750, 520], ...
        'Name', 'Tomahawk Autopilot Selection', ...
        'MenuBar', 'none', ...
        'NumberTitle', 'off', ...
        'WindowStyle', 'modal');

    bg = uibuttongroup('Parent', f, ...
        'Position', [0.02 0.50 0.96 0.46], ...
        'Title', 'Autopilot Control method', ...
        'FontSize', 14, ...
        'FontWeight', 'bold');

    radio1 = uicontrol(bg, ...
        'Style', 'radiobutton', ...
        'FontSize', 13, ...
        'String', 'SLC:  (course control + altitude), LOSchi', ...
        'Position', [10 105 700 30], ...
        'Tag', '1', ...
        'Value', 1);

    radio2 = uicontrol(bg, ...
        'Style', 'radiobutton', ...
        'FontSize', 13, ...
        'String', 'LQR:  (heading + altitude LQR), ALOSpsi', ...
        'Position', [10 60 700 30], ...
        'Tag', '2');

    radio3 = uicontrol(bg, ...
        'Style', 'radiobutton', ...
        'FontSize', 13, ...
        'String', 'LQR:  (heading + altitude LQR), LOSchi (crab-corrected)', ...
        'Position', [10 15 700 30], ...
        'Tag', '3');

    bgWind = uibuttongroup('Parent', f, ...
        'Position', [0.02 0.18 0.96 0.28], ...
        'Title', 'Environmental conditions', ...
        'FontSize', 14, ...
        'FontWeight', 'bold');

    radioWind1 = uicontrol(bgWind, ...
        'Style', 'radiobutton', ...
        'FontSize', 13, ...
        'String', 'Dryden wind on:  (light-med turbulence)', ...
        'Position', [10 70 700 30], ...
        'Tag', '1', ...
        'Value', 1);

    radioWind2 = uicontrol(bgWind, ...
        'Style', 'radiobutton', ...
        'FontSize', 13, ...
        'String', 'Dryden wind off:  (calm air, diagnostic baseline)', ...
        'Position', [10 25 700 30], ...
        'Tag', '2');

    uicontrol('Style', 'pushbutton', ...
        'String', 'OK', ...
        'FontSize', 13, ...
        'Position', [20 30 100 40], ...
        'Callback', @(~,~) uiresume(f));

    uiwait(f);

    if ~isvalid(f)
        ControlFlag = 1;
        WindFlag = 1;
        return;
    end

    if get(radio1, 'Value') == 1
        ControlFlag = 1;
    elseif get(radio2, 'Value') == 1
        ControlFlag = 2;
    else
        ControlFlag = 3;
    end

    if get(radioWind1, 'Value') == 1
        WindFlag = 1;
    else
        WindFlag = 2;
    end

    close(f);

    % Summary printout
    disp('------------------------------------------------------------------------');
    disp('Tomahawk 6-DOF Simulation');
    disp('------------------------------------------------------------------------');

    switch ControlFlag
        case 1
            disp('Lateral autopilot:   SLC course control (bank-to-turn) + yaw damper');
            disp('Longitudinal AP:     SLC altitude hold (pitch rate -> theta -> h)');
            disp('Guidance:            LOSchi (Fossen 2021, direct course command)');
        case 2
            disp('Lateral autopilot:   LQR full-state [da, dr] (heading tracking)');
            disp('Longitudinal AP:     LQR full-state [de] (altitude tracking)');
            disp('Guidance:            ALOSpsi + LOSobserver (psi_d heading command)');
        case 3
            disp('Lateral autopilot:   LQR full-state [da, dr] (heading tracking)');
            disp('Longitudinal AP:     LQR full-state [de] (altitude tracking)');
            disp('Guidance:            LOSchi (course) -> psi_cmd = chi_d - crab');
    end

    if WindFlag == 1
        disp('Environment:         Dryden gusts ON (light-med turbulence)');
    else
        disp('Environment:         Dryden gusts OFF (calm air baseline)');
    end

    disp('------------------------------------------------------------------------');
    disp('Simulating...');
end

function x_next = rk4_wind(dt, t, x, p, ctrl_fun, wind_b)
    k1 = tomahawk_eom(t,         x,            p, ctrl_fun, wind_b);
    k2 = tomahawk_eom(t + dt/2,  x + dt/2*k1,  p, ctrl_fun, wind_b);
    k3 = tomahawk_eom(t + dt/2,  x + dt/2*k2,  p, ctrl_fun, wind_b);
    k4 = tomahawk_eom(t + dt,    x + dt*k3,    p, ctrl_fun, wind_b);
    x_next = x + (dt/6) * (k1 + 2*k2 + 2*k3 + k4);
end
