function p = tomahawk_params()
% TOMAHAWK_PARAMS  6-DOF aerodynamic model parameters for a Tomahawk-class
%   subsonic cruise missile.  All coefficients derived from an OpenVSP /
%   VSPAERO vortex-lattice analysis at Mach 0.75.
%
%   Formulation follows Beard & McLain, "Small Unmanned Aircraft",
%   Chapters 2-4, as presented in the TTK 4190 lecture notes.
%
%   Usage:  p = tomahawk_params();

%% ---- Physical constants ------------------------------------------------
p.g     = 9.81;         % gravitational acceleration  [m/s^2]
p.rho0  = 1.225;        % ISA sea-level air density   [kg/m^3]

%% ---- Operating point ---------------------------------------------------
p.Mach       = 0.75;
p.Va_trim    = 257;      % trim airspeed  [m/s]   (Mach 0.75 at low alt.)
p.alpha_trim = 1.65;     % initial openvsp trim angle of attack  [deg]
p.beta_trim  = 0;        % trim sideslip angle   [deg]

%% ---- Reference geometry ------------------------------------------------
p.S     = 0.98496;       % reference (wing) area       [m^2]
p.c     = 0.456;         % reference (mean aero) chord [m]
p.b     = 2.16;          % reference (wing) span       [m]

%% ---- Mass and inertia --------------------------------------------------
p.mass  = 1300.121;      % total vehicle mass  [kg]

%   Inertia tensor about CG in body frame.
%   Off-diagonal product Ixz is small but retained for completeness.
%   Convention:  J = [Jx   0   Jxz ;
%                      0  Jy    0  ;
%                     Jxz  0   Jz ]
%   (Jxy = Jyz = 0 by vehicle symmetry about the xz-plane.)
p.Jx    = 146;           % [kg*m^2]  
p.Jy    = 3087.633;      % [kg*m^2]
p.Jz    = 3093.426;      % [kg*m^2]
p.Jxz   = 0.612;         % [kg*m^2]

%   Pre-compute the Gamma constants used in the rotational EoM
%   (Beard & McLain, Ch. 3, slide 18):
Gam         = p.Jx * p.Jz - p.Jxz^2;
p.Gam1      = p.Jxz * (p.Jx - p.Jy + p.Jz) / Gam;
p.Gam2      = (p.Jz * (p.Jz - p.Jy) + p.Jxz^2) / Gam;
p.Gam3      = p.Jz  / Gam;
p.Gam4      = p.Jxz / Gam;
p.Gam5      = (p.Jz - p.Jx) / p.Jy;
p.Gam6      = p.Jxz / p.Jy;
p.Gam7      = ((p.Jx - p.Jy) * p.Jx + p.Jxz^2) / Gam;
p.Gam8      = p.Jx  / Gam;

%% ---- Static aerodynamic fits (alpha in RADIANS) -----------------------
%   Polynomial fits from OpenVSP wide-alpha sweeps, converted to radians.
%   Form:  C(alpha) = a3*alpha^3 + a2*alpha^2 + a1*alpha + a0
p.CL_poly = [  0.0000,   0.0000,  5.1813,  0.1869];   % [a3 a2 a1 a0]
p.CD_poly = [  0.0000,   2.2651,  0.1432,  0.0381];
p.Cm_poly = [  0.0000,   0.0000, -2.3516,  0.06772];

%% ---- Longitudinal dynamic derivatives (per rad, at trim) ---------------
p.CL_q       =  19.2066;
p.CD_q       =  -0.1820;
p.Cm_q       = -64.4265;

%% ---- Longitudinal control derivatives (symmetric elevon, per rad) ------
p.CL_de      =   0.3647;
p.CD_de      =   0.0081;
p.Cm_de      =  -2.7607;

%% ---- Lateral-directional stability derivatives (per rad, at trim) ------
%   Trim values CY0, Cl0, Cn0 are effectively zero for a symmetric vehicle
%   (< 1e-3), so they are set to zero in the model.
p.CY0        =  0;
p.Cl0        =  0;
p.Cn0        =  0;

p.CY_beta    = -0.8066;
p.Cl_beta    = -0.1177;
p.Cn_beta    =  0.4724;

p.CY_p       =  0.0329;
p.CY_r       =  2.2492;
p.Cl_p       = -1.0749;
p.Cl_r       =  0.1703;
p.Cn_p       = -0.1771;
p.Cn_r       = -2.7053;

%% ---- Lateral-directional control derivatives (per rad) -----------------
%   delta_a = wing ailerons (roll), delta_r = rudder (yaw).
p.CY_da      = -0.005;
p.Cl_da      =  0.30;        
p.Cn_da      =  0.015;       

p.CY_dr      =  0.3807;
p.Cl_dr      = -0.0007;
p.Cn_dr      = -0.5527;

%% ---- Trim thrust -------------------------------------------------------
%   Constant thrust that balances aerodynamic drag at the trim condition,
%   allowing sustained level flight without a propulsion sub-model.
%   Computed from the body-x force balance at trim:
%       T = qbar * S * (CD*cos(a0) - CL*sin(a0)) + m*g*sin(a0)
a0       = deg2rad(p.alpha_trim);
qbar0    = 0.5 * p.rho0 * p.Va_trim^2;
CL0_trim = polyval(p.CL_poly, a0);
CD0_trim = polyval(p.CD_poly, a0);
p.T_trim = qbar0 * p.S * (CD0_trim * cos(a0) - CL0_trim * sin(a0)) ...
         + p.mass * p.g * sin(a0);

%% ---- Control-surface limits --------------------------------------------
%   Physical elevevator, aileron and rudder deflection limits. 
%   Saturation should be applied to the physical surfaces.
p.elevon_max = deg2rad(15);   % [rad]  physical elevon limit
p.aileron_max = deg2rad(15);  % [rad] physical airleron limit
p.rudder_max = deg2rad(15);   % [rad]  rudder limit

end
