function [alpha_t, de_t, info] = tomahawk_trim(p)
% TOMAHAWK_TRIM  Find the trimmed angle of attack and elevator deflection
%   for steady, level, unaccelerated flight (gamma = 0, beta = 0).
%
%   [alpha_t, de_t, info] = tomahawk_trim(p)
%
%   Solves two coupled residual equations via Newton iteration:
%     (1)  Body-z force balance   :  -CZ(alpha, de) * qbar * S = m*g*cos(alpha)
%     (2)  Pitching-moment balance:  Cm(alpha, de) = 0
%
%   where CZ = -CD*sin(alpha) - CL*cos(alpha)  is the body-z aero coeff.,
%   and the total CL, CD, Cm include the elevator contribution.
%
%   Inputs
%     p  : parameter struct from tomahawk_params()
%
%   Outputs
%     alpha_t : trimmed angle of attack  [rad]
%     de_t    : trimmed elevator (symmetric elevon) deflection  [rad]
%     info    : struct with convergence details
%
%   Formulation follows Beard & McLain Ch. 4 (TTK 4190 lecture notes).

%% ---- Constants ---------------------------------------------------------
qbar  = 0.5 * p.rho0 * p.Va_trim^2;
W     = p.mass * p.g;

%% ---- Initial guess from the parameter-file trim point ------------------
alpha = deg2rad(p.alpha_trim);
de    = 0;

%% ---- Newton iteration --------------------------------------------------
tol      = 1e-12;
max_iter = 50;
da_fd    = 1e-7;        % finite-difference step for Jacobian

converged = false;
for k = 1:max_iter
    % Evaluate residual at current (alpha, de)
    F = residual(alpha, de, qbar, p, W);

    if norm(F) < tol
        converged = true;
        break;
    end

    % Jacobian via central finite differences
    %   J = [dF1/dalpha  dF1/dde ;
    %        dF2/dalpha  dF2/dde ]
    Fp_a = residual(alpha + da_fd, de, qbar, p, W);
    Fm_a = residual(alpha - da_fd, de, qbar, p, W);
    Fp_e = residual(alpha, de + da_fd, qbar, p, W);
    Fm_e = residual(alpha, de - da_fd, qbar, p, W);

    J = [(Fp_a - Fm_a), (Fp_e - Fm_e)] / (2 * da_fd);

    % Newton step
    dx    = -J \ F;
    alpha = alpha + dx(1);
    de    = de    + dx(2);
end

% Re-evaluate the residual at the final (alpha, de). The in-loop check
% runs at the top of the iteration, so the last Newton update is never
% tested before max_iter exits. Set the flag from the actual final state.
F = residual(alpha, de, qbar, p, W);
converged = norm(F) < tol;

%% ---- Outputs -----------------------------------------------------------
alpha_t = alpha;
de_t    = de;

% Recompute trim thrust from the body-x balance:
%   T = -fx_aero - mg*sin(alpha)
%   fx_aero = qbar*S*CX,  CX = -CD*cos(alpha) + CL*sin(alpha)
[CL, CD, ~] = aero_coeffs(alpha, de, p);
CX   = -CD * cos(alpha) + CL * sin(alpha);
T_trim = -qbar * p.S * CX + W * sin(alpha);

info.converged  = converged;
info.iterations = k;
info.residual   = norm(F);
info.T_trim     = T_trim;
info.CL         = CL;
info.CD         = CD;
info.qbar       = qbar;
info.L_over_D   = CL / CD;

% Print summary
fprintf('--- Trim solver (Newton iteration) ---\n');
fprintf('  Converged     : %s  (%d iterations, |F| = %.2e)\n', ...
        string(converged), k, norm(F));
fprintf('  alpha_trim    = %.4f deg  (%.5f rad)\n', rad2deg(alpha_t), alpha_t);
fprintf('  de_trim       = %.4f deg  (%.5f rad)\n', rad2deg(de_t), de_t);
fprintf('  T_trim        = %.2f N\n', T_trim);
fprintf('  CL(trim)      = %.6f\n', CL);
fprintf('  CD(trim)      = %.6f\n', CD);
fprintf('  L/D           = %.2f\n', CL/CD);
fprintf('  Lift          = %.1f N\n', qbar * p.S * CL);
fprintf('  Weight        = %.1f N\n', W);
fprintf('\n');

end

%% ========================================================================
function F = residual(alpha, de, qbar, p, W)
% Evaluate the two trim residual equations:
%   F(1) :  body-z force balance  (should be zero for gamma = 0)
%   F(2) :  pitching-moment balance

    [CL, CD, Cm] = aero_coeffs(alpha, de, p);

    % Body-z aero coefficient
    CZ = -CD * sin(alpha) - CL * cos(alpha);

    % F(1):  sum of z-forces = 0
    %   aero_z + gravity_z = 0
    %   qbar*S*CZ + W*cos(alpha) = 0      (theta = alpha for gamma = 0)
    F(1) = qbar * p.S * CZ + W * cos(alpha);

    % F(2):  sum of pitching moments = 0
    F(2) = Cm;

    F = F(:);
end

%% ========================================================================
function [CL, CD, Cm] = aero_coeffs(alpha, de, p)
% Total CL, CD, Cm at given alpha and elevator, with rates = 0.
    CL = polyval(p.CL_poly, alpha) + p.CL_de * de;
    CD = polyval(p.CD_poly, alpha) + p.CD_de * de;
    Cm = polyval(p.Cm_poly, alpha) + p.Cm_de * de;
end
