function [de, da, dr] = const_ctrl(~, ~, u_vec)
% CONST_CTRL  Return constant control deflections.
%   [de, da, dr] = const_ctrl(t, x, u_vec)
%   u_vec = [de; da; dr]
    de = u_vec(1);
    da = u_vec(2);
    dr = u_vec(3);
end
