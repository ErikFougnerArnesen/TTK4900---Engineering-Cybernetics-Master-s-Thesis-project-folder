function ds = drydenWindInit(dt, Va0, turb_level, wind_ned)
% DRYDENWINDINIT  Initialize the Dryden gust model state and filter matrices.
%
%   ds = drydenWindInit(dt, Va0, turb_level, wind_ned)
%
%   Computes the discrete-time state-space filter matrices for the Dryden
%   transfer functions (Beard & McLain Ch. 4.4, Table 4.1) using
%   exact zero-order hold discretization of the continuous-time realization.
%   (Åström and Wittenmark Ch. 2, section 2.2 and 2.3)
%   Inputs:
%     dt         : simulation time step [s]
%     Va0        : nominal airspeed for filter design [m/s]
%     turb_level : turbulence intensity, one of:
%                    'low-light'  : low altitude, light turbulence (50 m)
%                    'low-mod'    : low altitude, moderate turbulence (50 m)
%                    'med-light'  : medium altitude, light turbulence (600 m)
%                    'med-mod'    : medium altitude, moderate turbulence (600 m)
%     wind_ned   : steady wind velocity in NED [wn; we; wd] [m/s]
%
%   Output:
%     ds : struct containing filter matrices and state vectors
%
%   Reference:
%     Beard & McLain, "Small Unmanned Aircraft"
%     Åström and Wittenmark, "Computer-Controlled Systems: Theory and Design" (Prentice Hall, 3rd ed. 1997)
% 
%
%   See also: drydenWindModel

% =========================================================================
% Dryden parameters from Beard Table 4.1    MIL-F-8785C, via Beard & McLain
% =========================================================================
switch turb_level
    case 'low-light'
        Lu = 200;  Lv = 200;  Lw = 50;
        sigma_u = 1.06;  sigma_v = 1.06;  sigma_w = 0.7;
    case 'low-mod'
        Lu = 200;  Lv = 200;  Lw = 50;
        sigma_u = 2.12;  sigma_v = 2.12;  sigma_w = 1.4;
    case 'med-light'
        Lu = 533;  Lv = 533;  Lw = 533;
        sigma_u = 1.5;   sigma_v = 1.5;   sigma_w = 1.5;
    case 'med-mod'
        Lu = 533;  Lv = 533;  Lw = 533;
        sigma_u = 3.0;   sigma_v = 3.0;   sigma_w = 3.0;
    otherwise
        error('Unknown turbulence level: %s', turb_level);
end

% =========================================================================
% u-channel: first-order filter
%   H_u(s) = K_u / (s + a_u)                        Beard & McLain Sec. 4.4   
%   Continuous state-space:  xdot = -a_u * x + e,   y = K_u * x
% =========================================================================
a_u = Va0 / Lu;
K_u = sigma_u * sqrt(2 * Va0 / (pi * Lu));

% Exact ZOH discretization                     Astrom & Wittenmark Sec. 2.3
Ac_u = -a_u;
Ad_u = exp(Ac_u * dt);
Bd_u = (1/a_u) * (1 - exp(-a_u * dt));
Cd_u = K_u;

% =========================================================================
% v-channel: second-order filter
%   H_v(s) = K_v * (s + b_v) / (s + a_v)^2          Beard & McLain Sec. 4.4
%   Controllable canonical form:               Astrom & Wittenmark Sec. 2.2
%     A_c = [0, 1; -a_v^2, -2*a_v],  B_c = [0; 1]
%     C_c = [K_v*b_v, K_v],           D_c = 0
% =========================================================================
a_v = Va0 / Lv;
b_v = Va0 / (sqrt(3) * Lv);
K_v = sigma_v * sqrt(3 * Va0 / (pi * Lv));
%                                              Astrom & Wittenmark Sec. 2.2
Ac_v = [0, 1; -a_v^2, -2*a_v];
Bc_v = [0; 1];
Cd_v = [K_v * b_v, K_v];

% Exact ZOH discretization                     Astrom & Wittenmark Sec. 2.3
Ad_v = expm(Ac_v * dt);
Bd_v = Ac_v \ (Ad_v - eye(2)) * Bc_v;

% =========================================================================
% w-channel: second-order filter (same structure as v)
%   H_w(s) = K_w * (s + b_w) / (s + a_w)^2          
% =========================================================================
a_w = Va0 / Lw;
b_w = Va0 / (sqrt(3) * Lw);
K_w = sigma_w * sqrt(3 * Va0 / (pi * Lw));
%                                              
Ac_w = [0, 1; -a_w^2, -2*a_w];
Bc_w = [0; 1];
Cd_w = [K_w * b_w, K_w];
% Exact ZOH discretization                     
Ad_w = expm(Ac_w * dt);
Bd_w = Ac_w \ (Ad_w - eye(2)) * Bc_w;

% =========================================================================
% Pack into output struct
% =========================================================================
ds.dt = dt;
ds.Va0 = Va0;

% Filter matrices
ds.Ad_u = Ad_u;  ds.Bd_u = Bd_u;  ds.Cd_u = Cd_u;
ds.Ad_v = Ad_v;  ds.Bd_v = Bd_v;  ds.Cd_v = Cd_v;
ds.Ad_w = Ad_w;  ds.Bd_w = Bd_w;  ds.Cd_w = Cd_w;

% Filter states (initialized to zero)
ds.x_u = 0;
ds.x_v = zeros(2, 1);
ds.x_w = zeros(2, 1);

% Steady wind in NED
ds.wind_ned = wind_ned(:);

% Store parameters for reference
ds.turb_level = turb_level;
ds.sigma = [sigma_u, sigma_v, sigma_w];
ds.L     = [Lu, Lv, Lw];

fprintf('--- Dryden wind model initialized ---\n');
fprintf('  Turbulence  : %s\n', turb_level);
fprintf('  sigma       : [%.1f, %.1f, %.1f] m/s\n', sigma_u, sigma_v, sigma_w);
fprintf('  L           : [%.0f, %.0f, %.0f] m\n', Lu, Lv, Lw);
fprintf('  Steady wind : [%.1f, %.1f, %.1f] m/s (NED)\n', ...
    wind_ned(1), wind_ned(2), wind_ned(3));
fprintf('  Va0 (design): %.1f m/s\n', Va0);
fprintf('  dt          : %.4f s\n\n', dt);

end
