function lin = tomahawk_linearize(p, x_trim, u_trim)
% TOMAHAWK_LINEARIZE  Linearize the 6-DOF EOM about a trim condition.
%
%   lin = tomahawk_linearize(p, x_trim, u_trim)
%
%   Computes the full 12x12 Jacobian A and 12x3 Jacobian B by central
%   finite differences on tomahawk_eom, then extracts:
%     - Lateral state-space model     (Beard & McLain eq. 5.42)
%     - Longitudinal state-space model (Beard & McLain eq. 5.49)
%     - SLC transfer function parameters (a_phi1, a_phi2, a_theta1, ...)
%     - Open-loop eigenvalues and classical modes
%
%   Inputs
%     p       : parameter struct from tomahawk_params()
%     x_trim  : 12x1 trim state vector
%               [pn pe pd  u v w  phi theta psi  p q r]'
%               For level flight: u=Va*cos(alpha), w=Va*sin(alpha),
%               theta=alpha, all others zero (except position).
%     u_trim  : 3x1 trim control vector [de_trim; da_trim; dr_trim] [rad]
%
%   Output
%     lin     : struct with fields:
%       .A, .B           - full 12x12 and 12x3 Jacobians
%       .A_lon, .B_lon   - longitudinal: x_lon = [u w q theta h]'
%                          u_lon = [de]  (no throttle in this model)
%       .A_lat, .B_lat   - lateral: x_lat = [v p r phi psi]'
%                          u_lat = [da dr]
%       .eig_lon, .eig_lat - eigenvalues
%       .a_phi1, .a_phi2 - roll SLC parameters
%       .a_theta1, .a_theta2, .a_theta3 - pitch SLC parameters
%       .a_beta1, .a_beta2 - sideslip TF parameters
%       .a_V1, .a_V3     - airspeed TF parameters (no throttle => no a_V2)

%% ---- Numerical Jacobians via central differences -----------------------
nx = 12;   % number of states
nu = 3;    % number of controls: [de, da, dr]
eps_x = 1e-6;   % perturbation size for states
eps_u = 1e-6;   % perturbation size for controls

% Trim control as a function handle (constant)
ctrl_trim = @(t, x) const_ctrl(t, x, u_trim);

% Evaluate f at trim (should be approximately zero for trim states)
f0 = tomahawk_eom(0, x_trim, p, ctrl_trim);

% --- A matrix: df/dx ---
A = zeros(nx, nx);
for j = 1:nx
    xp = x_trim;  xp(j) = xp(j) + eps_x;
    xm = x_trim;  xm(j) = xm(j) - eps_x;
    fp = tomahawk_eom(0, xp, p, ctrl_trim);
    fm = tomahawk_eom(0, xm, p, ctrl_trim);
    A(:, j) = (fp - fm) / (2 * eps_x);
end

% --- B matrix: df/du ---
B = zeros(nx, nu);
for j = 1:nu
    up = u_trim;  up(j) = up(j) + eps_u;
    um = u_trim;  um(j) = um(j) - eps_u;
    ctrl_p = @(t, x) const_ctrl(t, x, up);
    ctrl_m = @(t, x) const_ctrl(t, x, um);
    fp = tomahawk_eom(0, x_trim, p, ctrl_p);
    fm = tomahawk_eom(0, x_trim, p, ctrl_m);
    B(:, j) = (fp - fm) / (2 * eps_u);
end

lin.A = A;
lin.B = B;
lin.f0 = f0;  % full state derivative at the linearization point

% --- Trim residual diagnostics -------------------------------------------
% norm(f0) is NOT a trim metric: f0(1:3) are the NED position derivatives,
% which are SUPPOSED to be nonzero for a translating vehicle (dpn/dt ~ Va).
% That term alone dominates the norm (~Va) and has nothing to do with
% whether the point is a dynamic equilibrium.
%
% The meaningful residual is the norm of the DYNAMIC rows only:
%   velocities (u,v,w), attitude rates of change (phi,theta,psi),
%   and body angular rates (p,q,r). For straight-and-level trim these
%   must all be ~0; the position rows and (for a turn) psi_dot need not be.
%
% State ordering: [pn pe pd  u v w  phi theta psi  p  q  r]
%                   1  2  3   4 5 6   7    8    9  10 11 12
dyn_idx  = [4 5 6 7 8 9 10 11 12];   % everything except NED position
core_idx = [4 5 6 10 11 12];          % must-be-zero: body vel + body rates

lin.trim_residual_full = norm(f0);            % old metric (kept for comparison)
lin.trim_residual_dyn  = norm(f0(dyn_idx));   % excludes position kinematics
lin.trim_residual_core = norm(f0(core_idx));  % the one that really matters

fprintf('\n--- Trim residual breakdown ---\n');
fprintf('  full   norm(f0)              = %.3e   (dominated by dpn/dt ~ Va, not a trim metric)\n', lin.trim_residual_full);
fprintf('  dynamic (no position rows)   = %.3e\n', lin.trim_residual_dyn);
fprintf('  core    (body vel + rates)   = %.3e   <-- equilibrium check\n', lin.trim_residual_core);
labels = {'pn_dot','pe_dot','pd_dot','u_dot','v_dot','w_dot', ...
          'phi_dot','theta_dot','psi_dot','p_dot','q_dot','r_dot'};
fprintf('  component breakdown:\n');
for ii = 1:12
    fprintf('    %-10s = %+.4e\n', labels{ii}, f0(ii));
end

%% ---- Extract sub-models (Beard & McLain Appendix F) --------------------
% State ordering:  [pn pe pd  u v w  phi theta psi  p  q  r ]
%                    1  2  3  4 5 6   7    8    9  10 11 12

% Longitudinal: x_lon = [u, w, q, theta, h]' , u_lon = [de]
% Note: h = -pd, so dh/dt = -dpd/dt.  The h row in A comes from row 3
%   with a sign flip, and the h column is column 3 with a sign flip.
lon_idx = [4, 6, 11, 8];   % [u, w, q, theta] in the 12-state
A_lon_4 = A(lon_idx, lon_idx);
B_lon_4 = B(lon_idx, 1);   % elevator is input 1

% Augment with altitude h = -pd
% dh/dt = -dpd/dt = -(A(3,:)*x + B(3,:)*u)
% In terms of lon states: dh/dt depends on u, w, theta (from row 3)
% plus h itself (column 3 in A, but sign-flipped)
h_row_A = -A(3, lon_idx);      % dependence of h_dot on [u, w, q, theta]
h_col_A = -A(lon_idx, 3);      % dependence of [u_dot, w_dot, q_dot, theta_dot] on pd
h_hh    = -A(3, 3);            % not really, A(3,3) is dpd_dot/dpd -> sign flip
% Actually dh_dot/dh = -d(pd_dot)/d(pd) = -A(3,3)

A_lon = [A_lon_4,   h_col_A;
         h_row_A,   h_hh];
B_lon = [B_lon_4;
         -B(3, 1)];

% Lateral: x_lat = [v, p, r, phi, psi]', u_lat = [da, dr]
lat_idx = [5, 10, 12, 7, 9];
A_lat = A(lat_idx, lat_idx);
B_lat = B(lat_idx, [2, 3]);    % aileron=input 2, rudder=input 3

lin.A_lon = A_lon;
lin.B_lon = B_lon;
lin.A_lat = A_lat;
lin.B_lat = B_lat;

%% ---- Eigenvalue analysis -----------------------------------------------
lin.eig_lon = eig(A_lon);
lin.eig_lat = eig(A_lat);

% Identify longitudinal modes
eig_lon = lin.eig_lon;
% Remove the (near-)zero eigenvalue (altitude mode)
complex_eigs = eig_lon(abs(imag(eig_lon)) > 1e-6);
if length(complex_eigs) >= 4
    % Two conjugate pairs: short period (larger wn) and phugoid (smaller wn)
    wn_all = abs(complex_eigs);
    [~, idx_sort] = sort(wn_all, 'descend');
    complex_eigs = complex_eigs(idx_sort);
    
    lin.short_period.wn   = abs(complex_eigs(1));
    lin.short_period.zeta = -real(complex_eigs(1)) / abs(complex_eigs(1));
    lin.phugoid.wn        = abs(complex_eigs(3));
    lin.phugoid.zeta      = -real(complex_eigs(3)) / abs(complex_eigs(3));
end

% Identify lateral modes
eig_lat = lin.eig_lat;
real_eigs_lat = eig_lat(abs(imag(eig_lat)) < 1e-6);
complex_eigs_lat = eig_lat(abs(imag(eig_lat)) > 1e-6);

% Sort real eigenvalues
real_vals = real(real_eigs_lat);
[~, idx_sort] = sort(real_vals);
real_eigs_lat = real_eigs_lat(idx_sort);

if ~isempty(complex_eigs_lat)
    lin.dutch_roll.wn   = abs(complex_eigs_lat(1));
    lin.dutch_roll.zeta = -real(complex_eigs_lat(1)) / abs(complex_eigs_lat(1));
end

% Roll mode: most negative real eigenvalue (fast, stable)
% Spiral mode: small positive or near-zero real eigenvalue
for k = 1:length(real_eigs_lat)
    rv = real(real_eigs_lat(k));
    if abs(rv) < 1e-8
        % near-zero (heading mode)
        continue;
    elseif rv > 0
        lin.spiral.eigenvalue = real_eigs_lat(k);
        lin.spiral.time_to_double = log(2) / rv;
    else
        % Largest magnitude negative real = roll mode
        if ~isfield(lin, 'roll_mode') || abs(rv) > abs(real(lin.roll_mode.eigenvalue))
            lin.roll_mode.eigenvalue = real_eigs_lat(k);
            lin.roll_mode.time_constant = -1/rv;
        end
    end
end

%% ---- SLC Transfer Function Coefficients --------------------------------
% These come from the linearized sub-models, following Beard Ch. 5.

% --- Lateral: Roll dynamics ---
% x_lat = [v, p, r, phi, psi], index: v=1, p=2, r=3, phi=4, psi=5
% From the A_lat matrix:
%   p_dot = L_v*v + L_p*p + L_r*r + 0*phi + 0*psi
% The roll transfer function phi(s)/da(s) is:
%   phi_ddot + a_phi1*phi_dot = a_phi2*da  (+ disturbances)
% where a_phi1 = -L_p  and  a_phi2 = L_da

L_p  = A_lat(2, 2);   % dp_dot/dp
L_da = B_lat(2, 1);   % dp_dot/d(da)

lin.a_phi1 = -L_p;
lin.a_phi2 =  L_da;

fprintf('  a_phi1 = %10.4f  (roll damping)\n', lin.a_phi1);
fprintf('  a_phi2 = %10.4f  (aileron effectiveness)\n', lin.a_phi2);

% --- Lateral: Sideslip dynamics ---
% beta(s)/dr(s) = a_beta2 / (s + a_beta1)
% From v_dot = Y_v*v + ... + Y_dr*dr, and v ~ Va*beta:
Y_v  = A_lat(1, 1);
Y_dr = B_lat(1, 2);

lin.a_beta1 = -Y_v;
lin.a_beta2 =  Y_dr / p.Va_trim;   % scale by 1/Va since beta = v/Va

fprintf('  a_beta1 = %10.4f  (sideslip damping)\n', lin.a_beta1);
fprintf('  a_beta2 = %10.4f  (rudder -> sideslip)\n', lin.a_beta2);

% --- Longitudinal: Pitch dynamics ---
% x_lon = [u, w, q, theta, h], index: u=1, w=2, q=3, theta=4, h=5
% The simplified pitch transfer function (Beard eq. 5.27):
%   theta(s)/de(s) = a_theta3 / (s^2 + a_theta1*s + a_theta2)
%
% From the state space, the [q, theta] subsystem gives:
%   q_dot = M_u*u + M_w*w + M_q*q + 0*theta + M_de*de
%   theta_dot = q
%
% Short-period approximation (freeze u, ignore h):
%   [w_dot]     [Z_w  Z_q] [w]     [Z_de]
%   [q_dot]  =  [M_w  M_q] [q]  +  [M_de] * de
%
%   plus theta_dot = q
%
% Transfer function theta/de from the 3-state [w, q, theta]:
%   We can compute it exactly from the sub-system.

% Extract the [w, q, theta] sub-block for pitch TF
A_wqt = A_lon([2 3 4], [2 3 4]);   % [w, q, theta] rows/cols
B_wqt = B_lon([2 3 4], 1);         % de column

% theta/de = C * (sI - A_wqt)^-1 * B_wqt  with C = [0 0 1]
% Compute characteristic polynomial of A_wqt
char_poly = charpoly(A_wqt);  % coeffs of s^3 + ... + c0

% But Beard uses the further-simplified 2nd order TF:
%   theta_ddot + a_theta1*theta_dot + a_theta2*theta = a_theta3*de
% This comes from the [q, theta] subsystem alone (short period approx
% that lumps w dynamics into q):
M_q  = A_lon(3, 3);
M_de = B_lon(3, 1);

% a_theta1 captures the effective pitch damping
% a_theta2 captures the pitch stiffness (from w coupling)
% a_theta3 = M_de

% More precisely, using the short-period reduction:
Z_w = A_lon(2, 2);
Z_q = A_lon(2, 3);
M_w = A_lon(3, 2);
Z_de = B_lon(2, 1);

% The 2nd order pitch TF from reducing the [w,q,theta] system:
%   s^2 + (-(Z_w + M_q))*s + (M_q*Z_w - M_w*Z_q) = (M_de - M_w*Z_de/...)*de
% But Beard's simpler version from eq. 5.27 uses:
%   a_theta1 = -M_q  (approximation for cruise missiles with strong M_q)
%   a_theta2 = -(from gravity/speed coupling, often small for cruise)
%   a_theta3 = M_de

% Use the exact short-period 2nd order form:
lin.a_theta1 = -(Z_w + M_q);                         % effective damping
lin.a_theta2 = M_q * Z_w - M_w * Z_q;                % effective stiffness
lin.a_theta3 = M_de;                                  % simplified (Beard)

fprintf('  a_theta1 = %10.4f  (pitch damping, exact short-period)\n', lin.a_theta1);
fprintf('  a_theta2 = %10.4f  (pitch stiffness)\n', lin.a_theta2);
fprintf('  a_theta3 = %10.4f  (elevator effectiveness, simplified)\n', lin.a_theta3);

% --- Longitudinal: Airspeed dynamics ---
% V_dot = -g*cos(theta* - alpha*)*theta_bar + a_V1_term*V_bar + ...
% Since we have no throttle: a_V2 = 0
X_u = A_lon(1, 1);
lin.a_V1 = -X_u;
lin.a_V3 = p.g * cos(x_trim(8) - atan2(x_trim(6), x_trim(4)));

fprintf('  a_V1 = %10.4f  (airspeed damping)\n', lin.a_V1);
fprintf('  a_V3 = %10.4f  (pitch -> airspeed coupling)\n', lin.a_V3);

%% ---- SLC Gain Computation Helper ---------------------------------------
% Store trim info for gain computation
lin.Va_trim = p.Va_trim;
lin.g = p.g;

%% ---- Print summary -----------------------------------------------------
fprintf('\n=== Linearization Summary ===\n');
fprintf('Trim residual (core, body vel+rates): %.2e\n', lin.trim_residual_core);
fprintf('\nLongitudinal eigenvalues:\n');
for k = 1:length(lin.eig_lon)
    e = lin.eig_lon(k);
    if abs(imag(e)) > 1e-6
        fprintf('  %+.4f %+.4fj  (wn=%.4f, zeta=%.4f)\n', ...
            real(e), imag(e), abs(e), -real(e)/abs(e));
    else
        fprintf('  %+.4f\n', real(e));
    end
end

fprintf('\nLateral eigenvalues:\n');
for k = 1:length(lin.eig_lat)
    e = lin.eig_lat(k);
    if abs(imag(e)) > 1e-6
        fprintf('  %+.4f %+.4fj  (wn=%.4f, zeta=%.4f)\n', ...
            real(e), imag(e), abs(e), -real(e)/abs(e));
    else
        fprintf('  %+.4f\n', real(e));
    end
end

if isfield(lin, 'short_period')
    fprintf('\nShort period:  wn = %.3f rad/s, zeta = %.4f\n', ...
        lin.short_period.wn, lin.short_period.zeta);
end
if isfield(lin, 'phugoid')
    fprintf('Phugoid:       wn = %.4f rad/s, zeta = %.4f\n', ...
        lin.phugoid.wn, lin.phugoid.zeta);
end
if isfield(lin, 'dutch_roll')
    fprintf('Dutch roll:    wn = %.3f rad/s, zeta = %.4f\n', ...
        lin.dutch_roll.wn, lin.dutch_roll.zeta);
end
if isfield(lin, 'roll_mode')
    fprintf('Roll mode:     tau = %.4f s  (eig = %.3f)\n', ...
        lin.roll_mode.time_constant, real(lin.roll_mode.eigenvalue));
end
if isfield(lin, 'spiral')
    fprintf('Spiral mode:   T_double = %.1f s  (eig = %.6f)\n', ...
        lin.spiral.time_to_double, real(lin.spiral.eigenvalue));
end

end