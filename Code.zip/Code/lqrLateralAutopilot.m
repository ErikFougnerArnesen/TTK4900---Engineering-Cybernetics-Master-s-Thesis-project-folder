function [da, dr, debug, state] = lqrLateralAutopilot(...
    psi_cmd, psi, phi, v_r, p_rate, r_rate, K, p, dt, state)
% LQRLATERALAUTOPILOT  LQR lateral autopilot for heading tracking.
%
%   [da, dr, debug, state] = lqrLateralAutopilot(psi_cmd, psi, phi, ...
%       v_r, p_rate, r_rate, K, p, dt, state)
%
%   Applies the precomputed LQR gain matrix K to the augmented lateral
%   state vector to produce simultaneous aileron and rudder commands.
%   The LQR naturally handles roll-yaw coupling through the full-state
%   feedback, eliminating the limit-cycle instability seen in the SISO
%   successive loop closure heading autopilot.
%
%   A first-order reference model smooths the heading command to prevent
%   large step inputs from driving the controller into saturation.
%
%   Augmented state:  xi = [v_r, p, r, phi, e_psi, x_I]'
%     v_r   : body-frame air-relative lateral velocity [m/s]
%              (= v_body - v_wind_body_y; equals sideslip velocity)
%     p     : roll rate [rad/s]
%     r     : yaw rate [rad/s]
%     phi   : roll angle [rad]
%     e_psi : heading error, ssa(psi - psi_cmd_filtered) [rad]
%     x_I   : integral of heading error [rad*s]
%
%   Control law:  u = -K * xi  ->  [da; dr]
%
%   Inputs:
%     psi_cmd : commanded heading angle [rad]
%     psi     : current heading (yaw) angle [rad]
%     phi     : roll angle [rad]
%     v_r     : air-relative body lateral velocity [m/s]
%     p_rate  : roll rate [rad/s]
%     r_rate  : yaw rate [rad/s]
%     K       : LQR gain matrix (2x6) from lqrLateralDesign()
%     p       : parameter struct from tomahawk_params()
%     dt      : sampling time [s]
%     state   : struct with persistent states:
%                 state.psi_int : heading error integral [rad*s]
%                 state.psi_d   : filtered heading command [rad]
%
%   Outputs:
%     da    : aileron command [rad]
%     dr    : rudder command [rad]
%     debug : struct with internal signals for diagnostics
%     state : updated state struct

% =========================================================================
% Reference model: smooth the heading command
% =========================================================================
%   First-order lag on psi_cmd to prevent step-input saturation.
%   Uses ssa() for correct angle wrapping across +/-pi.
wn_ref = 2.0;   % reference model bandwidth [rad/s] was 0.6
psi_rate_max = 0.027; % max heading rate [rad/s] (1.3 deg/s, ~35 deg bank)

psi_rate     = wn_ref * ssa(psi_cmd - state.psi_d);
psi_rate     = max(-psi_rate_max, min(psi_rate_max, psi_rate));
psi_cmd_filt = state.psi_d + psi_rate * dt;
state.psi_d  = psi_cmd_filt;


%psi_cmd_filt = state.psi_d + ssa(psi_cmd - state.psi_d) * wn_ref * dt;
%state.psi_d  = psi_cmd_filt;

% =========================================================================
% Heading error with angle wrapping (against filtered command)
% =========================================================================
e_psi = ssa(psi - psi_cmd_filt);

% =========================================================================
% Assemble augmented state vector
% =========================================================================
%   xi = [v_r, p, r, phi, e_psi, x_I]'
%
%   Notes:
%   - v_r is the air-relative sideslip velocity, matching the linearized
%     aero model.  In no-wind conditions, v_r = v_body (state x(5)).
%   - phi and the angular rates are body states, used directly.
%   - e_psi replaces the raw psi perturbation because the psi column of
%     A_lat is all zeros (free integrator), so the LQR only uses psi
%     through its gain K(:,5) acting on the heading error.

xi = [v_r; p_rate; r_rate; phi; e_psi; state.psi_int];

% =========================================================================
% LQR control law: u = -K * xi
% =========================================================================
u = -K * xi;
da_raw = u(1);
dr_raw = u(2);

% =========================================================================
% Saturate at physical limits
% =========================================================================
da = max(-p.aileron_max, min(p.aileron_max, da_raw));
dr = max(-p.rudder_max,  min(p.rudder_max,  dr_raw));

% =========================================================================
% Propagate integral state with anti-windup
% =========================================================================
%   Back-calculation anti-windup: only integrate when BOTH actuators are
%   unsaturated, or when the error is driving the integral toward zero
%   (reducing windup).  This prevents the integral from growing when the
%   LQR commands cannot be realized due to surface limits.

da_sat = (abs(da_raw) > p.aileron_max);
dr_sat = (abs(dr_raw) > p.rudder_max);

if ~(da_sat || dr_sat) || (e_psi * state.psi_int < 0)
    state.psi_int = state.psi_int + dt * e_psi;
end

% Hard clamp as final safety net
psi_int_max = deg2rad(5) * 10;   % ~0.87 rad*s
state.psi_int = max(-psi_int_max, min(psi_int_max, state.psi_int));

% =========================================================================
% Debug output
% =========================================================================
debug.e_psi    = e_psi;
debug.xi       = xi;
debug.da_raw   = da_raw;
debug.dr_raw   = dr_raw;
debug.da       = da;
debug.dr       = dr;

end
